export type UserRole = 'customer' | 'restaurant_owner' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar?: string;
  walletBalance: number;
  createdAt: string;
  isEmailVerified: boolean;
  failedLoginAttempts?: number;
  isLocked?: boolean;
}

export interface Address {
  id: string;
  userId: string;
  title: 'Home' | 'Work' | 'Other';
  flatNo: string;
  area: string;
  landmark?: string;
  city: string;
  pincode: string;
  isDefault: boolean;
  lat?: number;
  lng?: number;
}

export type VegNonVeg = 'veg' | 'non-veg' | 'egg';

export interface CustomizationOption {
  id: string;
  name: string;
  price: number;
}

export interface CustomizationGroup {
  id: string;
  title: string;
  required: boolean;
  options: CustomizationOption[];
}

export interface FoodItem {
  id: string;
  restaurantId: string;
  restaurantName?: string;
  name: string;
  description: string;
  price: number;
  discountPrice?: number;
  category: string; // e.g. 'Pizza', 'Burger', 'Biryani'
  image: string;
  rating: number;
  ratingCount: number;
  type: VegNonVeg;
  prepTimeMinutes: number;
  calories?: number;
  isAvailable: boolean;
  isBestseller?: boolean;
  customizationGroups?: CustomizationGroup[];
}

export interface FoodCategory {
  id: string;
  name: string;
  icon: string; // Lucide icon or emoji/image URL
  image: string;
  description: string;
  itemCount: number;
}

export interface RestaurantCategory {
  id: string;
  name: string;
}

export interface Restaurant {
  id: string;
  name: string;
  slug: string;
  logo: string;
  banner: string;
  rating: number;
  reviewCount: number;
  cuisines: string[];
  address: string;
  city: string;
  pincode: string;
  avgCostForTwo: number;
  deliveryTimeMinutes: number;
  deliveryFee: number;
  isOpen: boolean;
  openingHours: string;
  isPromoted?: boolean;
  discountBadge?: string;
  isPureVeg?: boolean;
  phone: string;
  ownerId?: string;
}

export interface CartItemOption {
  groupId: string;
  groupTitle: string;
  optionId: string;
  optionName: string;
  price: number;
}

export interface CartItem {
  id: string;
  foodItem: FoodItem;
  restaurantId: string;
  restaurantName: string;
  quantity: number;
  selectedOptions: CartItemOption[];
  specialInstructions?: string;
  unitTotal: number;
  itemTotal: number;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'flat';
  discountValue: number;
  maxDiscount?: number;
  minOrderValue: number;
  description: string;
  expiryDate: string;
  isActive: boolean;
}

export type OrderStatus = 'placed' | 'confirmed' | 'preparing' | 'ready' | 'out_for_delivery' | 'delivered' | 'cancelled';
export type PaymentMethod = 'cod' | 'razorpay' | 'stripe' | 'paypal' | 'upi' | 'card' | 'wallet';
export type PaymentStatus = 'pending' | 'completed' | 'failed' | 'refunded';

export interface OrderItem {
  id: string;
  foodItemId: string;
  name: string;
  price: number;
  quantity: number;
  selectedOptions: CartItemOption[];
  totalPrice: number;
  image?: string;
}

export interface DeliveryDriver {
  name: string;
  phone: string;
  photo: string;
  vehicleNumber: string;
  rating: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  customerName: string;
  customerPhone: string;
  restaurantId: string;
  restaurantName: string;
  restaurantAddress: string;
  deliveryAddress: Address;
  items: OrderItem[];
  itemTotal: number;
  deliveryFee: number;
  packagingFee: number;
  taxAmount: number;
  discountAmount: number;
  tipAmount: number;
  grandTotal: number;
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  transactionId?: string;
  orderNotes?: string;
  placedAt: string;
  estimatedDeliveryTime: string;
  driver?: DeliveryDriver;
  couponCodeApplied?: string;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  restaurantId: string;
  restaurantName: string;
  foodItemId?: string;
  rating: number;
  comment: string;
  createdAt: string;
  orderId?: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  createdAt: string;
  isRead: boolean;
  type: 'order' | 'offer' | 'system';
}

export interface AnalyticsData {
  dailySales: { date: string; amount: number; orders: number }[];
  monthlySales: { month: string; amount: number; orders: number }[];
  topCategories: { name: string; sales: number }[];
  topDishes: { name: string; quantity: number; revenue: number }[];
  topRestaurants: { name: string; orders: number; revenue: number }[];
  overallStats: {
    totalRevenue: number;
    totalOrders: number;
    activeCustomers: number;
    activeRestaurants: number;
    avgOrderValue: number;
  };
}

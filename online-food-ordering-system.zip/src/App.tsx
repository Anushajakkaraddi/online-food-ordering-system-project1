import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { CategoryBar } from './components/CategoryBar';
import { OffersSection } from './components/OffersSection';
import { RestaurantCard } from './components/RestaurantCard';
import { RestaurantDetailView } from './components/RestaurantDetailView';
import { FoodCustomizationModal } from './components/FoodCustomizationModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { CustomerDashboard } from './components/CustomerDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { DocumentationModal } from './components/DocumentationModal';
import { LocationModal } from './components/LocationModal';
import { AuthModal } from './components/AuthModal';
import { Footer } from './components/Footer';
import { Filter, Star, Clock, Sparkles } from 'lucide-react';

const MainContent: React.FC = () => {
  const { 
    currentView, setCurrentView, 
    restaurantsList, searchQuery, 
    selectedCategory, setSelectedCategory 
  } = useApp();

  // Filter restaurants
  let filteredRestaurants = [...restaurantsList];

  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase();
    filteredRestaurants = filteredRestaurants.filter(r => 
      r.name.toLowerCase().includes(q) || 
      r.cuisines.some(c => c.toLowerCase().includes(q))
    );
  }

  if (selectedCategory) {
    filteredRestaurants = filteredRestaurants.filter(r => 
      r.cuisines.some(c => c.toLowerCase() === selectedCategory.toLowerCase())
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col selection:bg-orange-500 selection:text-white">
      
      {/* Header */}
      <Header />

      {/* Primary Page Switcher */}
      <main className="flex-1">
        {currentView === 'home' && (
          <div>
            <HeroBanner />
            <CategoryBar />
            <OffersSection />

            {/* Popular Restaurants Grid */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-orange-500" />
                    <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                      Popular Restaurants Near You
                    </h2>
                  </div>
                  <p className="text-slate-500 text-xs sm:text-sm mt-0.5">
                    Handpicked top gourmet outlets delivering hot & fresh in Metro City
                  </p>
                </div>

                <button
                  onClick={() => setCurrentView('restaurants')}
                  className="px-4 py-2 rounded-xl bg-slate-900 text-white font-bold text-xs hover:bg-slate-800 transition-colors cursor-pointer w-fit"
                >
                  View All Outlets ({restaurantsList.length}) →
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {restaurantsList.slice(0, 8).map(restaurant => (
                  <RestaurantCard key={restaurant.id} restaurant={restaurant} />
                ))}
              </div>
            </div>
          </div>
        )}

        {currentView === 'restaurants' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                  {selectedCategory ? `${selectedCategory} Outlets` : 'All Partner Restaurants'}
                </h1>
                <p className="text-xs sm:text-sm text-slate-500 mt-1">
                  Showing {filteredRestaurants.length} active delivery spots
                </p>
              </div>

              {selectedCategory && (
                <button
                  onClick={() => setSelectedCategory(null)}
                  className="text-xs font-bold text-orange-600 bg-orange-50 px-3 py-1.5 rounded-full border border-orange-200 cursor-pointer hover:bg-orange-100 transition-colors"
                >
                  Clear Category Filter ×
                </button>
              )}
            </div>

            {filteredRestaurants.length === 0 ? (
              <div className="py-16 text-center bg-white rounded-3xl border border-slate-200">
                <h3 className="font-extrabold text-slate-800 text-lg">No restaurants found</h3>
                <p className="text-slate-500 text-xs mt-1">Try adjusting your search keywords or category filters.</p>
                <button
                  onClick={() => setSelectedCategory(null)}
                  className="mt-4 px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs cursor-pointer shadow-xs transition-colors"
                >
                  Show All Restaurants
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredRestaurants.map(restaurant => (
                  <RestaurantCard key={restaurant.id} restaurant={restaurant} />
                ))}
              </div>
            )}
          </div>
        )}

        {currentView === 'restaurant_detail' && <RestaurantDetailView />}
        {currentView === 'checkout' && <CheckoutModal />}
        {currentView === 'order_tracking' && <OrderTrackingModal />}
        {currentView === 'customer_dashboard' && <CustomerDashboard />}
        {currentView === 'admin_dashboard' && <AdminDashboard />}
      </main>

      {/* Global Drawers and Modals */}
      <FoodCustomizationModal />
      <CartDrawer />
      <LocationModal />
      <AuthModal />
      <DocumentationModal />

      {/* Footer */}
      <Footer />

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}

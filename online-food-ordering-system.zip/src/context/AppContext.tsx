import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User, Address, Restaurant, FoodItem, FoodCategory, CartItem, 
  Order, Coupon, Review, NotificationItem, UserRole, CartItemOption 
} from '../types';
import { 
  INITIAL_USER, INITIAL_ADDRESSES, RESTAURANTS, FOOD_ITEMS, 
  FOOD_CATEGORIES, AVAILABLE_COUPONS, MOCK_ORDERS, MOCK_REVIEWS 
} from '../data/mockData';

export type PageView = 
  | 'home'
  | 'restaurants'
  | 'restaurant_detail'
  | 'food_detail'
  | 'cart'
  | 'checkout'
  | 'order_success'
  | 'order_tracking'
  | 'customer_dashboard'
  | 'admin_dashboard'
  | 'documentation'
  | 'faq'
  | 'about'
  | 'contact';

interface AppContextType {
  // Navigation & View
  currentView: PageView;
  setCurrentView: (view: PageView) => void;
  selectedRestaurantId: string | null;
  setSelectedRestaurantId: (id: string | null) => void;
  selectedFoodItem: FoodItem | null;
  setSelectedFoodItem: (item: FoodItem | null) => void;
  selectedCategory: string | null;
  setSelectedCategory: (cat: string | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  
  // User & Auth
  currentUser: User;
  setCurrentUser: React.Dispatch<React.SetStateAction<User>>;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  addresses: Address[];
  setAddresses: React.Dispatch<React.SetStateAction<Address[]>>;
  selectedAddress: Address | null;
  setSelectedAddress: (addr: Address | null) => void;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  
  // Restaurants & Menu
  restaurantsList: Restaurant[];
  foodItemsList: FoodItem[];
  categoriesList: FoodCategory[];
  wishlist: string[]; // Food item IDs
  favoriteRestaurants: string[]; // Restaurant IDs
  toggleWishlist: (foodId: string) => void;
  toggleFavoriteRestaurant: (restId: string) => void;

  // Cart & Checkout
  cartItems: CartItem[];
  addToCart: (food: FoodItem, quantity?: number, selectedOptions?: CartItemOption[], specialInstructions?: string) => void;
  removeFromCart: (cartItemId: string) => void;
  updateCartQuantity: (cartItemId: string, delta: number) => void;
  clearCart: () => void;
  cartSubtotal: number;
  appliedCoupon: Coupon | null;
  couponDiscount: number;
  applyCoupon: (code: string) => { success: boolean; message: string };
  removeCoupon: () => void;
  deliveryTip: number;
  setDeliveryTip: (amount: number) => void;
  orderInstructions: string;
  setOrderInstructions: (notes: string) => void;
  isCartDrawerOpen: boolean;
  setIsCartDrawerOpen: (open: boolean) => void;

  // Orders & Tracking
  orders: Order[];
  activeOrder: Order | null;
  setActiveOrder: (order: Order | null) => void;
  placeOrder: (paymentMethod: any, deliveryAddress: Address) => Promise<Order>;
  cancelOrder: (orderId: string) => void;

  // Notifications & Reviews
  notifications: NotificationItem[];
  markNotificationRead: (id: string) => void;
  reviews: Review[];
  addReview: (review: Omit<Review, 'id' | 'createdAt'>) => void;

  // UI Modals & Helpers
  isLocationModalOpen: boolean;
  setIsLocationModalOpen: (open: boolean) => void;
  isDocumentationModalOpen: boolean;
  setIsDocumentationModalOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<PageView>('home');
  const [selectedRestaurantId, setSelectedRestaurantId] = useState<string | null>('rest_1');
  const [selectedFoodItem, setSelectedFoodItem] = useState<FoodItem | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // User State
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem('crave_user');
    return saved ? JSON.parse(saved) : INITIAL_USER;
  });
  const [userRole, setUserRole] = useState<UserRole>(currentUser.role);
  const [addresses, setAddresses] = useState<Address[]>(INITIAL_ADDRESSES);
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(INITIAL_ADDRESSES[0] || null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Restaurants & Food
  const [restaurantsList] = useState<Restaurant[]>(RESTAURANTS);
  const [foodItemsList] = useState<FoodItem[]>(FOOD_ITEMS);
  const [categoriesList] = useState<FoodCategory[]>(FOOD_CATEGORIES);
  const [wishlist, setWishlist] = useState<string[]>(['food_101', 'food_201']);
  const [favoriteRestaurants, setFavoriteRestaurants] = useState<string[]>(['rest_1', 'rest_2']);

  // Cart
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('crave_cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [deliveryTip, setDeliveryTip] = useState<number>(2.00);
  const [orderInstructions, setOrderInstructions] = useState<string>('');
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState<boolean>(false);

  // Orders
  const [orders, setOrders] = useState<Order[]>(MOCK_ORDERS);
  const [activeOrder, setActiveOrder] = useState<Order | null>(MOCK_ORDERS[0] || null);

  // Notifications & Reviews
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif_1',
      userId: currentUser.id,
      title: 'Order Out for Delivery! 🛵',
      message: 'Driver David Miller is on the way with your Hyderabadi Biryani.',
      createdAt: '10 mins ago',
      isRead: false,
      type: 'order',
    },
    {
      id: 'notif_2',
      userId: currentUser.id,
      title: 'Special Coupon Unlocked 🎉',
      message: 'Use code CRAVE50 for 50% OFF up to $10 on your next order.',
      createdAt: '1 hour ago',
      isRead: true,
      type: 'offer',
    },
  ]);
  const [reviews, setReviews] = useState<Review[]>(MOCK_REVIEWS);

  // Modals
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<boolean>(false);
  const [isDocumentationModalOpen, setIsDocumentationModalOpen] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('crave_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('crave_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  const toggleWishlist = (foodId: string) => {
    setWishlist(prev => 
      prev.includes(foodId) ? prev.filter(id => id !== foodId) : [...prev, foodId]
    );
  };

  const toggleFavoriteRestaurant = (restId: string) => {
    setFavoriteRestaurants(prev => 
      prev.includes(restId) ? prev.filter(id => id !== restId) : [...prev, restId]
    );
  };

  // Cart Logic
  const addToCart = (
    food: FoodItem, 
    quantity: number = 1, 
    selectedOptions: CartItemOption[] = [], 
    specialInstructions: string = ''
  ) => {
    // Check if adding from different restaurant
    if (cartItems.length > 0 && cartItems[0].restaurantId !== food.restaurantId) {
      if (!window.confirm('Your cart contains items from another restaurant. Would you like to clear your cart and start a new order?')) {
        return;
      }
      setCartItems([]);
    }

    const optionsPrice = selectedOptions.reduce((acc, opt) => acc + opt.price, 0);
    const unitTotal = (food.discountPrice || food.price) + optionsPrice;
    
    // Check if exact same item with same options exists
    const optionsKey = JSON.stringify(selectedOptions.sort((a,b) => a.optionId.localeCompare(b.optionId)));
    
    setCartItems(prev => {
      const existingIndex = prev.findIndex(item => 
        item.foodItem.id === food.id && 
        JSON.stringify(item.selectedOptions.sort((a,b) => a.optionId.localeCompare(b.optionId))) === optionsKey
      );

      if (existingIndex > -1) {
        const updated = [...prev];
        const item = updated[existingIndex];
        const newQty = item.quantity + quantity;
        updated[existingIndex] = {
          ...item,
          quantity: newQty,
          itemTotal: Number((unitTotal * newQty).toFixed(2)),
        };
        return updated;
      } else {
        const newItem: CartItem = {
          id: `cart_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          foodItem: food,
          restaurantId: food.restaurantId,
          restaurantName: food.restaurantName || 'Restaurant',
          quantity,
          selectedOptions,
          specialInstructions,
          unitTotal: Number(unitTotal.toFixed(2)),
          itemTotal: Number((unitTotal * quantity).toFixed(2)),
        };
        return [...prev, newItem];
      }
    });

    setIsCartDrawerOpen(true);
  };

  const removeFromCart = (cartItemId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== cartItemId));
  };

  const updateCartQuantity = (cartItemId: string, delta: number) => {
    setCartItems(prev => prev.map(item => {
      if (item.id === cartItemId) {
        const newQty = item.quantity + delta;
        if (newQty <= 0) return null;
        return {
          ...item,
          quantity: newQty,
          itemTotal: Number((item.unitTotal * newQty).toFixed(2)),
        };
      }
      return item;
    }).filter(Boolean) as CartItem[]);
  };

  const clearCart = () => {
    setCartItems([]);
    setAppliedCoupon(null);
  };

  const cartSubtotal = cartItems.reduce((acc, item) => acc + item.itemTotal, 0);

  // Coupon Calculation
  let couponDiscount = 0;
  if (appliedCoupon && cartSubtotal >= appliedCoupon.minOrderValue) {
    if (appliedCoupon.discountType === 'percentage') {
      couponDiscount = (cartSubtotal * appliedCoupon.discountValue) / 100;
      if (appliedCoupon.maxDiscount && couponDiscount > appliedCoupon.maxDiscount) {
        couponDiscount = appliedCoupon.maxDiscount;
      }
    } else {
      couponDiscount = appliedCoupon.discountValue;
    }
  }

  const applyCoupon = (code: string) => {
    const coupon = AVAILABLE_COUPONS.find(c => c.code.toUpperCase() === code.trim().toUpperCase() && c.isActive);
    if (!coupon) {
      return { success: false, message: 'Invalid or expired promo code.' };
    }
    if (cartSubtotal < coupon.minOrderValue) {
      return { success: false, message: `Minimum order value of $${coupon.minOrderValue} required for this coupon.` };
    }
    setAppliedCoupon(coupon);
    return { success: true, message: `Coupon '${coupon.code}' applied successfully!` };
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
  };

  const placeOrder = async (paymentMethod: any, deliveryAddress: Address): Promise<Order> => {
    const rest = restaurantsList.find(r => r.id === (cartItems[0]?.restaurantId || 'rest_1')) || restaurantsList[0];
    const deliveryFee = cartSubtotal >= 25 ? 0 : (rest.deliveryFee || 1.99);
    const packagingFee = 1.00;
    const taxAmount = Number((cartSubtotal * 0.08).toFixed(2));
    const grandTotal = Number((cartSubtotal + deliveryFee + packagingFee + taxAmount - couponDiscount + deliveryTip).toFixed(2));

    const newOrder: Order = {
      id: `ord_${Date.now()}`,
      orderNumber: `CRV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      userId: currentUser.id,
      customerName: currentUser.name,
      customerPhone: currentUser.phone,
      restaurantId: rest.id,
      restaurantName: rest.name,
      restaurantAddress: rest.address,
      deliveryAddress,
      items: cartItems.map(item => ({
        id: `oi_${Math.random().toString(36).substr(2, 6)}`,
        foodItemId: item.foodItem.id,
        name: item.foodItem.name,
        price: item.unitTotal,
        quantity: item.quantity,
        selectedOptions: item.selectedOptions,
        totalPrice: item.itemTotal,
        image: item.foodItem.image,
      })),
      itemTotal: cartSubtotal,
      deliveryFee,
      packagingFee,
      taxAmount,
      discountAmount: Number(couponDiscount.toFixed(2)),
      tipAmount: deliveryTip,
      grandTotal,
      status: 'placed',
      paymentMethod,
      paymentStatus: 'completed',
      transactionId: `tx_${paymentMethod}_${Date.now()}`,
      orderNotes: orderInstructions,
      placedAt: new Date().toISOString(),
      estimatedDeliveryTime: '25-35 mins',
      driver: {
        name: 'Michael Scott',
        phone: '+1 (555) 777-9911',
        photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
        vehicleNumber: 'EV-302-CRV',
        rating: 4.9,
      },
      couponCodeApplied: appliedCoupon?.code,
    };

    setOrders(prev => [newOrder, ...prev]);
    setActiveOrder(newOrder);
    clearCart();
    return newOrder;
  };

  const cancelOrder = (orderId: string) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'cancelled' as const } : o));
    if (activeOrder?.id === orderId) {
      setActiveOrder(prev => prev ? { ...prev, status: 'cancelled' as const } : null);
    }
  };

  const markNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const addReview = (newRev: Omit<Review, 'id' | 'createdAt'>) => {
    const rev: Review = {
      ...newRev,
      id: `rev_${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setReviews(prev => [rev, ...prev]);
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        selectedRestaurantId,
        setSelectedRestaurantId,
        selectedFoodItem,
        setSelectedFoodItem,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        currentUser,
        setCurrentUser,
        userRole,
        setUserRole: (role) => {
          setUserRole(role);
          setCurrentUser(prev => ({ ...prev, role }));
        },
        addresses,
        setAddresses,
        selectedAddress,
        setSelectedAddress,
        isAuthModalOpen,
        setIsAuthModalOpen,
        restaurantsList,
        foodItemsList,
        categoriesList,
        wishlist,
        favoriteRestaurants,
        toggleWishlist,
        toggleFavoriteRestaurant,
        cartItems,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartSubtotal,
        appliedCoupon,
        couponDiscount,
        applyCoupon,
        removeCoupon,
        deliveryTip,
        setDeliveryTip,
        orderInstructions,
        setOrderInstructions,
        isCartDrawerOpen,
        setIsCartDrawerOpen,
        orders,
        activeOrder,
        setActiveOrder,
        placeOrder,
        cancelOrder,
        notifications,
        markNotificationRead,
        reviews,
        addReview,
        isLocationModalOpen,
        setIsLocationModalOpen,
        isDocumentationModalOpen,
        setIsDocumentationModalOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

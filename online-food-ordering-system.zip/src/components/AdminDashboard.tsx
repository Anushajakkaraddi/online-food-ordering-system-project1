import React, { useState } from 'react';
import { 
  BarChart2, Store, Utensils, ShoppingBag, Tag, Star, 
  Users, DollarSign, TrendingUp, Plus, Edit, Trash2, CheckCircle2, XCircle, Search, Shield 
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { useApp } from '../context/AppContext';
import { FoodItem, OrderStatus, Restaurant } from '../types';

export const AdminDashboard: React.FC = () => {
  const { 
    restaurantsList, foodItemsList, orders, reviews, 
    userRole, setUserRole 
  } = useApp();

  const [adminTab, setAdminTab] = useState<'analytics' | 'restaurants' | 'menu' | 'orders' | 'coupons' | 'reviews'>('analytics');
  const [orderSearch, setOrderSearch] = useState('');
  const [selectedRestFilter, setSelectedRestFilter] = useState<string>('all');

  // Sales Chart Data
  const salesData = [
    { date: 'Mon', revenue: 1420, orders: 42 },
    { date: 'Tue', revenue: 1850, orders: 58 },
    { date: 'Wed', revenue: 2100, orders: 64 },
    { date: 'Thu', revenue: 2890, orders: 89 },
    { date: 'Fri', revenue: 3950, orders: 124 },
    { date: 'Sat', revenue: 4890, orders: 168 },
    { date: 'Sun', revenue: 4200, orders: 142 },
  ];

  const categoryData = [
    { name: 'Biryani', sales: 1240 },
    { name: 'Pizza', sales: 980 },
    { name: 'Burger', sales: 850 },
    { name: 'Chinese', sales: 720 },
    { name: 'Desserts', sales: 540 },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-purple-900 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-purple-400" />
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">Admin & Restaurant Console</h1>
          </div>
          <p className="text-xs sm:text-sm text-purple-200 mt-1">
            Manage outlets, menu items, order fulfillment queues, coupons, and sales reports.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/10 text-xs font-bold">
          <span>Role:</span>
          <span className="capitalize text-amber-300 font-extrabold">{userRole.replace('_', ' ')}</span>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 border-b border-slate-200 scrollbar-none">
        {[
          { id: 'analytics', label: 'Sales & Analytics', icon: BarChart2 },
          { id: 'orders', label: 'Live Orders Queue', icon: ShoppingBag, badge: orders.length },
          { id: 'restaurants', label: 'Restaurants', icon: Store, badge: restaurantsList.length },
          { id: 'menu', label: 'Food Menu Manager', icon: Utensils, badge: foodItemsList.length },
          { id: 'coupons', label: 'Coupons', icon: Tag },
          { id: 'reviews', label: 'Customer Reviews', icon: Star, badge: reviews.length },
        ].map(tab => {
          const Icon = tab.icon;
          const isSelected = adminTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setAdminTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-xs transition-all shrink-0 cursor-pointer ${
                isSelected 
                  ? 'bg-purple-700 text-white shadow-md shadow-purple-500/20' 
                  : 'bg-white border border-slate-200/80 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge !== undefined && (
                <span className={`px-1.5 py-0.2 text-[10px] rounded-full font-black ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Sales Analytics Tab */}
      {adminTab === 'analytics' && (
        <div className="space-y-6">
          
          {/* KPI Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[11px] font-bold uppercase">Weekly Revenue</span>
                <DollarSign className="w-4 h-4 text-emerald-600" />
              </div>
              <span className="block text-2xl font-black text-slate-900 mt-2">$21,500.00</span>
              <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-0.5 mt-1">
                <TrendingUp className="w-3 h-3" /> +18.4% vs last week
              </span>
            </div>

            <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[11px] font-bold uppercase">Total Orders</span>
                <ShoppingBag className="w-4 h-4 text-purple-600" />
              </div>
              <span className="block text-2xl font-black text-slate-900 mt-2">687</span>
              <span className="text-[10px] text-purple-600 font-bold mt-1 block">Avg 98 orders/day</span>
            </div>

            <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[11px] font-bold uppercase">Active Outlets</span>
                <Store className="w-4 h-4 text-blue-600" />
              </div>
              <span className="block text-2xl font-black text-slate-900 mt-2">{restaurantsList.length}</span>
              <span className="text-[10px] text-slate-400 font-bold mt-1 block">100% operational</span>
            </div>

            <div className="p-5 rounded-3xl bg-white border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[11px] font-bold uppercase">Avg Order Value</span>
                <TrendingUp className="w-4 h-4 text-amber-600" />
              </div>
              <span className="block text-2xl font-black text-slate-900 mt-2">$28.40</span>
              <span className="text-[10px] text-amber-600 font-bold mt-1 block">+$2.10 vs last month</span>
            </div>
          </div>

          {/* Recharts Graphical Panels */}
          <div className="grid lg:grid-cols-12 gap-6">
            
            {/* Revenue Trend Area Chart */}
            <div className="lg:col-span-8 bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider">
                Daily Revenue Trend ($)
              </h3>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={salesData}>
                    <defs>
                      <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#9333ea" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#9333ea" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} />
                    <YAxis stroke="#94a3b8" fontSize={12} />
                    <Tooltip />
                    <Area type="monotone" dataKey="revenue" stroke="#9333ea" fillOpacity={1} fill="url(#colorRev)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Category Breakdown Bar Chart */}
            <div className="lg:col-span-4 bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
              <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider">
                Top Food Categories
              </h3>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={categoryData}>
                    <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} />
                    <YAxis stroke="#94a3b8" fontSize={10} />
                    <Tooltip />
                    <Bar dataKey="sales" fill="#e11d48" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* Live Orders Queue */}
      {adminTab === 'orders' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-slate-900 text-lg">Live Incoming Orders ({orders.length})</h3>
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Filter order number or customer..."
                value={orderSearch}
                onChange={(e) => setOrderSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-100 text-xs font-medium focus:bg-white border border-slate-200"
              />
            </div>
          </div>

          <div className="space-y-4">
            {orders.map(order => (
              <div key={order.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                  <div>
                    <span className="font-mono font-bold text-xs text-purple-700">#{order.orderNumber}</span>
                    <h4 className="font-extrabold text-slate-900 text-sm">{order.customerName} ({order.customerPhone})</h4>
                    <span className="text-[11px] text-slate-500">From {order.restaurantName} • {new Date(order.placedAt).toLocaleTimeString()}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-black text-rose-600 text-base">${order.grandTotal.toFixed(2)}</span>
                    <span className="px-2.5 py-1 rounded-lg bg-purple-100 text-purple-900 text-xs font-bold uppercase">
                      {order.status.replace(/_/g, ' ')}
                    </span>
                  </div>
                </div>

                <div className="divide-y divide-slate-100 text-xs">
                  {order.items.map(i => (
                    <div key={i.id} className="py-1 flex justify-between">
                      <span>{i.quantity}× {i.name}</span>
                      <span className="font-bold">${i.totalPrice.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Restaurants Manager Tab */}
      {adminTab === 'restaurants' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 space-y-4">
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-slate-900 text-lg">Manage Restaurant Partners</h3>
            <button
              onClick={() => alert('Simulated: Add New Restaurant Modal opened')}
              className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Partner Restaurant</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {restaurantsList.map(rest => (
              <div key={rest.id} className="p-4 rounded-2xl border border-slate-200 space-y-3 flex flex-col justify-between">
                <div className="flex items-center gap-3">
                  <img src={rest.logo} alt={rest.name} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900 line-clamp-1">{rest.name}</h4>
                    <p className="text-[11px] text-slate-500">{rest.cuisines.join(', ')}</p>
                    <span className="text-[10px] text-emerald-600 font-bold">★ {rest.rating} Rating ({rest.reviewCount} reviews)</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-bold">
                  <span className={rest.isOpen ? 'text-emerald-600' : 'text-rose-600'}>
                    {rest.isOpen ? '● Open Now' : '○ Closed'}
                  </span>
                  <div className="flex gap-2">
                    <button className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs">
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Menu Items Manager Tab */}
      {adminTab === 'menu' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 space-y-4">
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-slate-900 text-lg">Manage Food Dishes</h3>
            <button
              onClick={() => alert('Simulated: Add New Dish Form opened')}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Dish</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {foodItemsList.map(food => (
              <div key={food.id} className="p-3.5 rounded-2xl border border-slate-200 flex gap-3 items-center justify-between">
                <img src={food.image} alt={food.name} className="w-16 h-16 rounded-xl object-cover shrink-0" />
                <div className="min-w-0 flex-1">
                  <h5 className="font-extrabold text-xs text-slate-900 truncate">{food.name}</h5>
                  <p className="text-[10px] text-slate-500">{food.category} • {food.type}</p>
                  <span className="text-xs font-black text-rose-600">${food.price.toFixed(2)}</span>
                </div>
                <button className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs">
                  <Edit className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, Clock, MapPin, Phone, MessageSquare, Download, 
  XCircle, ChefHat, Bike, ShieldCheck, ArrowLeft, RefreshCw 
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { OrderStatus } from '../types';

export const OrderTrackingModal: React.FC = () => {
  const { activeOrder, cancelOrder, setCurrentView, setActiveOrder, orders } = useApp();
  const [simulatedStatus, setSimulatedStatus] = useState<OrderStatus>(activeOrder?.status || 'out_for_delivery');

  useEffect(() => {
    if (activeOrder) {
      setSimulatedStatus(activeOrder.status);
    }
  }, [activeOrder]);

  if (!activeOrder) {
    return (
      <div className="max-w-xl mx-auto my-12 p-8 text-center bg-white rounded-3xl border border-slate-200">
        <h3 className="font-extrabold text-slate-800 text-lg">No Active Order Selected</h3>
        <p className="text-slate-500 text-xs mt-1">Please select an order from your history.</p>
        <button
          onClick={() => setCurrentView('customer_dashboard')}
          className="mt-4 px-4 py-2 rounded-xl bg-rose-600 text-white font-bold text-xs cursor-pointer"
        >
          View Order History
        </button>
      </div>
    );
  }

  const steps: { key: OrderStatus; label: string; desc: string; icon: any }[] = [
    { key: 'placed', label: 'Order Confirmed', desc: 'Received by restaurant', icon: CheckCircle2 },
    { key: 'preparing', label: 'Preparing Food', desc: 'Chef is crafting your meal', icon: ChefHat },
    { key: 'out_for_delivery', label: 'Out for Delivery', desc: 'Driver is on the way', icon: Bike },
    { key: 'delivered', label: 'Food Delivered', desc: 'Enjoy your delicious meal!', icon: CheckCircle2 },
  ];

  const getStepIndex = (status: OrderStatus) => {
    switch (status) {
      case 'placed': return 0;
      case 'confirmed': return 0;
      case 'preparing': return 1;
      case 'ready': return 1;
      case 'out_for_delivery': return 2;
      case 'delivered': return 3;
      case 'cancelled': return -1;
      default: return 0;
    }
  };

  const currentStepIdx = getStepIndex(simulatedStatus);

  const handlePrintReceipt = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('customer_dashboard')}
            className="p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                Order #{activeOrder.orderNumber}
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold uppercase">
                {simulatedStatus.replace(/_/g, ' ')}
              </span>
            </div>
            <p className="text-xs text-slate-500">Placed on {new Date(activeOrder.placedAt).toLocaleString()}</p>
          </div>
        </div>

        <button
          onClick={handlePrintReceipt}
          className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Receipt</span>
        </button>
      </div>

      <div className="grid md:grid-cols-12 gap-6">
        
        {/* Left Column: Live Status & Map Simulator */}
        <div className="md:col-span-7 space-y-6">
          
          {/* Estimated Time Card */}
          <div className="bg-gradient-to-r from-slate-900 via-rose-950 to-slate-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400">
                  Estimated Delivery Time
                </span>
                <h2 className="text-3xl font-black text-white mt-1">
                  {simulatedStatus === 'delivered' ? 'Food Delivered 🎉' : activeOrder.estimatedDeliveryTime}
                </h2>
                <p className="text-xs text-slate-300 mt-1">
                  Delivering from <span className="font-bold">{activeOrder.restaurantName}</span>
                </p>
              </div>

              <div className="w-16 h-16 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <Clock className="w-8 h-8 animate-pulse" />
              </div>
            </div>
          </div>

          {/* Live Progress Stepper */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-6">
            <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider">
              Live Order Status
            </h3>

            <div className="relative pl-6 border-l-2 border-slate-200 space-y-6">
              {steps.map((step, idx) => {
                const Icon = step.icon;
                const isDone = currentStepIdx > idx || simulatedStatus === 'delivered';
                const isCurrent = currentStepIdx === idx && simulatedStatus !== 'delivered';

                return (
                  <div key={step.key} className="relative flex items-start gap-4">
                    
                    {/* Circle Bullet */}
                    <div className={`absolute -left-[31px] top-0 w-6 h-6 rounded-full flex items-center justify-center border-2 transition-all ${
                      isDone 
                        ? 'bg-emerald-600 border-emerald-600 text-white' 
                        : isCurrent 
                        ? 'bg-rose-600 border-rose-600 text-white animate-bounce' 
                        : 'bg-white border-slate-300 text-slate-400'
                    }`}>
                      <Icon className="w-3.5 h-3.5" />
                    </div>

                    <div>
                      <h4 className={`font-extrabold text-sm ${
                        isDone || isCurrent ? 'text-slate-900' : 'text-slate-400'
                      }`}>
                        {step.label}
                      </h4>
                      <p className="text-xs text-slate-500">{step.desc}</p>
                    </div>

                  </div>
                );
              })}
            </div>

            {/* Simulation Controller Buttons for Demo */}
            <div className="pt-4 border-t border-slate-100 flex flex-wrap gap-2 items-center justify-between text-xs">
              <span className="text-[10px] font-bold uppercase text-slate-400">Demo Controller:</span>
              <div className="flex gap-1.5 flex-wrap">
                {(['placed', 'preparing', 'out_for_delivery', 'delivered'] as OrderStatus[]).map(st => (
                  <button
                    key={st}
                    onClick={() => setSimulatedStatus(st)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                      simulatedStatus === st ? 'bg-slate-900 text-white border-slate-900' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {st.replace(/_/g, ' ')}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Delivery Driver Info */}
          {activeOrder.driver && (
            <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <img
                  src={activeOrder.driver.photo}
                  alt={activeOrder.driver.name}
                  className="w-12 h-12 rounded-2xl object-cover ring-2 ring-emerald-500/30"
                />
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">{activeOrder.driver.name}</h4>
                  <p className="text-xs text-slate-500">Delivery Executive • {activeOrder.driver.vehicleNumber}</p>
                  <span className="text-[11px] font-bold text-amber-600">★ {activeOrder.driver.rating} Rating</span>
                </div>
              </div>

              <div className="flex gap-2">
                <a
                  href={`tel:${activeOrder.driver.phone}`}
                  className="p-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold transition-colors cursor-pointer"
                  title="Call Delivery Agent"
                >
                  <Phone className="w-4 h-4" />
                </a>
              </div>
            </div>
          )}

        </div>

        {/* Right Column: Order Items & Delivery Location */}
        <div className="md:col-span-5 space-y-6">
          
          {/* Order Summary Box */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-sm uppercase tracking-wider border-b border-slate-100 pb-2">
              Order Details
            </h3>

            {/* Delivery Address */}
            <div className="flex items-start gap-2.5 text-xs">
              <MapPin className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-900">Delivering To</span>
                <p className="text-slate-600">{activeOrder.deliveryAddress.flatNo}, {activeOrder.deliveryAddress.area}</p>
              </div>
            </div>

            {/* Items List */}
            <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto space-y-2 text-xs">
              {activeOrder.items.map(item => (
                <div key={item.id} className="pt-2 flex justify-between items-center">
                  <div>
                    <span className="font-bold text-slate-900">{item.quantity}× {item.name}</span>
                    {item.selectedOptions.length > 0 && (
                      <p className="text-[10px] text-slate-400">
                        {item.selectedOptions.map(o => o.optionName).join(', ')}
                      </p>
                    )}
                  </div>
                  <span className="font-bold text-slate-900">${item.totalPrice.toFixed(2)}</span>
                </div>
              ))}
            </div>

            {/* Total Paid */}
            <div className="pt-3 border-t border-slate-200 flex justify-between items-center font-black text-sm text-slate-900">
              <span>Paid via {activeOrder.paymentMethod.toUpperCase()}</span>
              <span className="text-rose-600 text-base">${activeOrder.grandTotal.toFixed(2)}</span>
            </div>

            {/* Cancel Action if applicable */}
            {(simulatedStatus === 'placed' || simulatedStatus === 'confirmed') && (
              <button
                onClick={() => {
                  if (window.confirm('Are you sure you want to cancel this order?')) {
                    cancelOrder(activeOrder.id);
                  }
                }}
                className="w-full py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs border border-rose-200 transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <XCircle className="w-4 h-4" />
                <span>Cancel Order</span>
              </button>
            )}

          </div>

        </div>

      </div>

    </div>
  );
};

import React, { useState } from 'react';
import { 
  User as UserIcon, MapPin, ShoppingBag, Heart, Wallet, Bell, 
  Settings, LogOut, CheckCircle2, Clock, RotateCcw, Plus, Shield, Sparkles, Tag 
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Address } from '../types';

export const CustomerDashboard: React.FC = () => {
  const { 
    currentUser, setCurrentUser, 
    orders, activeOrder, setActiveOrder, setCurrentView,
    addresses, setAddresses, selectedAddress, setSelectedAddress,
    wishlist, foodItemsList, favoriteRestaurants, restaurantsList,
    addToCart, setIsCartDrawerOpen, notifications
  } = useApp();

  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'profile' | 'addresses' | 'wishlist' | 'wallet' | 'coupons'>('overview');

  // Edit Profile Form
  const [name, setName] = useState(currentUser.name);
  const [email, setEmail] = useState(currentUser.email);
  const [phone, setPhone] = useState(currentUser.phone);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setCurrentUser(prev => ({ ...prev, name, email, phone }));
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleReorder = (orderId: string) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    order.items.forEach(item => {
      const food = foodItemsList.find(f => f.id === item.foodItemId);
      if (food) {
        addToCart(food, item.quantity, item.selectedOptions);
      }
    });

    setIsCartDrawerOpen(true);
  };

  const wishlistFoods = foodItemsList.filter(f => wishlist.includes(f.id));
  const favRestaurants = restaurantsList.filter(r => favoriteRestaurants.includes(r.id));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      
      {/* Dashboard Top Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-rose-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
        
        <div className="flex items-center gap-4">
          <img
            src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200'}
            alt={currentUser.name}
            className="w-16 h-16 sm:w-20 sm:h-20 rounded-full object-cover ring-4 ring-rose-500/30"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white">{currentUser.name}</h1>
              <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold text-[10px] uppercase px-2 py-0.5 rounded-full">
                Verified Customer
              </span>
            </div>
            <p className="text-slate-300 text-xs mt-1">{currentUser.email} • {currentUser.phone}</p>
            <p className="text-slate-400 text-[11px] mt-0.5">Member since {currentUser.createdAt}</p>
          </div>
        </div>

        {/* Quick Wallet Stats */}
        <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md px-5 py-3 rounded-2xl border border-white/10 shrink-0">
          <Wallet className="w-8 h-8 text-amber-400" />
          <div>
            <span className="text-[10px] font-bold text-slate-300 uppercase tracking-wider">Hunger Wallet</span>
            <span className="block text-xl font-black text-amber-400">${currentUser.walletBalance.toFixed(2)}</span>
          </div>
        </div>

      </div>

      {/* Tabs Navigation */}
      <div className="flex gap-2 overflow-x-auto pb-2 border-b border-slate-200 scrollbar-none">
        {[
          { id: 'overview', label: 'Overview', icon: UserIcon },
          { id: 'orders', label: 'Order History', icon: ShoppingBag, badge: orders.length },
          { id: 'profile', label: 'Edit Profile', icon: Settings },
          { id: 'addresses', label: 'Addresses', icon: MapPin, badge: addresses.length },
          { id: 'wishlist', label: 'Wishlist', icon: Heart, badge: wishlist.length },
          { id: 'wallet', label: 'Hunger Wallet', icon: Wallet },
          { id: 'coupons', label: 'Coupons', icon: Tag },
        ].map(tab => {
          const Icon = tab.icon;
          const isSelected = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-xs transition-all shrink-0 cursor-pointer ${
                isSelected 
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-500/20' 
                  : 'bg-white border border-slate-200/80 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge !== undefined && (
                <span className={`px-1.5 py-0.2 text-[10px] rounded-full font-black ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          
          {/* Active Order Banner */}
          {activeOrder && activeOrder.status !== 'delivered' && activeOrder.status !== 'cancelled' && (
            <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-500 to-rose-600 text-white shadow-lg flex items-center justify-between gap-4">
              <div>
                <span className="px-2.5 py-0.5 rounded-full bg-black/20 text-[10px] font-black uppercase tracking-wider">
                  Live Order In Progress
                </span>
                <h3 className="text-lg font-black mt-1">Order #{activeOrder.orderNumber}</h3>
                <p className="text-xs text-amber-100 mt-0.5">From {activeOrder.restaurantName} • Arrival in {activeOrder.estimatedDeliveryTime}</p>
              </div>

              <button
                onClick={() => setCurrentView('order_tracking')}
                className="px-4 py-2 rounded-xl bg-white text-slate-900 font-extrabold text-xs shadow-md hover:bg-slate-100 transition-colors cursor-pointer shrink-0"
              >
                Track Live
              </button>
            </div>
          )}

          {/* KPI Cards Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-slate-400 text-[11px] font-bold uppercase">Total Orders</span>
              <span className="block text-2xl font-black text-slate-900 mt-1">{orders.length}</span>
            </div>
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-slate-400 text-[11px] font-bold uppercase">Saved Addresses</span>
              <span className="block text-2xl font-black text-slate-900 mt-1">{addresses.length}</span>
            </div>
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-slate-400 text-[11px] font-bold uppercase">Wishlist Items</span>
              <span className="block text-2xl font-black text-slate-900 mt-1">{wishlist.length}</span>
            </div>
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <span className="text-slate-400 text-[11px] font-bold uppercase">Total Saved</span>
              <span className="block text-2xl font-black text-emerald-600 mt-1">$42.50</span>
            </div>
          </div>

          {/* Recent Orders List */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-extrabold text-slate-900 text-base border-b border-slate-100 pb-3">
              Recent Orders
            </h3>

            <div className="space-y-3">
              {orders.map(order => (
                <div key={order.id} className="p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-extrabold text-sm text-slate-900">{order.restaurantName}</h4>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        order.status === 'delivered' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {order.status.replace(/_/g, ' ')}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                    </p>
                    <span className="text-[11px] text-slate-400">{new Date(order.placedAt).toLocaleDateString()} • ${order.grandTotal.toFixed(2)}</span>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setActiveOrder(order);
                        setCurrentView('order_tracking');
                      }}
                      className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs cursor-pointer"
                    >
                      Track
                    </button>
                    <button
                      onClick={() => handleReorder(order.id)}
                      className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs cursor-pointer flex items-center gap-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Reorder</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* Edit Profile Tab */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 max-w-xl space-y-4">
          <h3 className="font-extrabold text-slate-900 text-lg border-b border-slate-100 pb-3">Edit Profile</h3>
          
          <form onSubmit={handleSaveProfile} className="space-y-4 text-xs font-bold">
            <div>
              <label className="block text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-700 mb-1">Phone Number</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>

            {saveSuccess && (
              <p className="text-emerald-600 font-bold text-xs flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> Profile updated successfully!
              </p>
            )}

            <button
              type="submit"
              className="py-3 px-6 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md transition-colors cursor-pointer"
            >
              Save Changes
            </button>
          </form>
        </div>
      )}

      {/* Order History Tab */}
      {activeTab === 'orders' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 space-y-4">
          <h3 className="font-extrabold text-slate-900 text-lg border-b border-slate-100 pb-3">
            All Past Orders ({orders.length})
          </h3>

          <div className="space-y-4">
            {orders.map(order => (
              <div key={order.id} className="p-4 rounded-2xl border border-slate-200/80 bg-slate-50/50 space-y-3">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-200/80 pb-2 gap-2">
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-sm">{order.restaurantName}</h4>
                    <span className="text-[11px] text-slate-500">Order #{order.orderNumber} • {new Date(order.placedAt).toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-black text-rose-600 text-sm">${order.grandTotal.toFixed(2)}</span>
                    <button
                      onClick={() => handleReorder(order.id)}
                      className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs cursor-pointer flex items-center gap-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" /> Reorder
                    </button>
                  </div>
                </div>

                <div className="divide-y divide-slate-100 text-xs">
                  {order.items.map(i => (
                    <div key={i.id} className="py-1 flex justify-between">
                      <span className="text-slate-700">{i.quantity}x {i.name}</span>
                      <span className="font-bold text-slate-900">${i.totalPrice.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Wishlist Tab */}
      {activeTab === 'wishlist' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 space-y-4">
          <h3 className="font-extrabold text-slate-900 text-lg border-b border-slate-100 pb-3">
            Saved Food Favorites ({wishlistFoods.length})
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {wishlistFoods.map(food => (
              <div key={food.id} className="p-3.5 rounded-2xl border border-slate-200 flex gap-3 items-center">
                <img src={food.image} alt={food.name} className="w-16 h-16 rounded-xl object-cover shrink-0" />
                <div className="min-w-0 flex-1">
                  <h5 className="font-extrabold text-xs text-slate-900 truncate">{food.name}</h5>
                  <p className="text-xs font-black text-rose-600">${food.price.toFixed(2)}</p>
                  <button
                    onClick={() => addToCart(food, 1)}
                    className="mt-1 text-[11px] font-bold text-rose-600 hover:underline cursor-pointer"
                  >
                    + Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};

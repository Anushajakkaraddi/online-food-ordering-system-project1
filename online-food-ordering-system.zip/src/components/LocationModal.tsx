import React, { useState } from 'react';
import { X, MapPin, Search, Check, Navigation } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const LocationModal: React.FC = () => {
  const { isLocationModalOpen, setIsLocationModalOpen, addresses, selectedAddress, setSelectedAddress } = useApp();
  const [searchPincode, setSearchPincode] = useState('');

  if (!isLocationModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4">
        
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-rose-600" />
            <h3 className="font-extrabold text-slate-900 text-base">Select Delivery Location</h3>
          </div>
          <button
            onClick={() => setIsLocationModalOpen(false)}
            className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* GPS Location Button */}
        <button
          onClick={() => {
            alert('GPS Detected: Downtown Metro City (400018)');
            setIsLocationModalOpen(false);
          }}
          className="w-full py-3 px-4 rounded-2xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-extrabold text-xs border border-rose-200 flex items-center justify-center gap-2 transition-colors cursor-pointer"
        >
          <Navigation className="w-4 h-4 fill-rose-600 text-rose-600" />
          <span>Use Current GPS Location</span>
        </button>

        {/* Search Pincode Input */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search address or enter pincode..."
            value={searchPincode}
            onChange={(e) => setSearchPincode(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-100 text-xs font-medium focus:bg-white border border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500"
          />
        </div>

        {/* Saved Locations List */}
        <div className="space-y-2">
          <span className="text-[10px] font-bold uppercase text-slate-400">Saved Addresses</span>
          {addresses.map(addr => {
            const isSelected = selectedAddress?.id === addr.id;

            return (
              <div
                key={addr.id}
                onClick={() => {
                  setSelectedAddress(addr);
                  setIsLocationModalOpen(false);
                }}
                className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                  isSelected ? 'bg-rose-50 border-rose-500 text-rose-950 font-bold' : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
                }`}
              >
                <div>
                  <span className="text-xs font-black text-rose-600 uppercase">{addr.title}</span>
                  <p className="text-xs text-slate-700">{addr.flatNo}, {addr.area}</p>
                  <span className="text-[10px] text-slate-400">{addr.city} - {addr.pincode}</span>
                </div>
                {isSelected && <Check className="w-4 h-4 text-rose-600 stroke-[3]" />}
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};

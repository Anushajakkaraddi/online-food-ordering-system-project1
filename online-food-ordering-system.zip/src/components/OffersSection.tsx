import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Tag, Check, Copy, Percent, Sparkles } from 'lucide-react';

export const OffersSection: React.FC = () => {
  const { applyCoupon, setIsCartDrawerOpen } = useApp();
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const offers = [
    {
      code: 'CRAVE50',
      title: '50% OFF Up To $10',
      desc: 'Valid on orders above $15 from all participating outlets.',
      color: 'from-orange-500 to-amber-600',
    },
    {
      code: 'WELCOME20',
      title: '20% OFF Welcome Deal',
      desc: 'Special discount for first 3 orders on CraveCraft.',
      color: 'from-amber-500 to-orange-500',
    },
    {
      code: 'FREEDEL',
      title: 'Free Delivery Pass',
      desc: 'Waives standard delivery charges on orders over $12.',
      color: 'from-slate-800 to-slate-900',
    },
  ];

  const handleApply = (code: string) => {
    setCopiedCode(code);
    applyCoupon(code);
    setTimeout(() => setCopiedCode(null), 2000);
    setIsCartDrawerOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-5 h-5 text-orange-500" />
        <h2 className="text-lg font-black text-slate-900 tracking-tight">Today's Hot Offers & Promo Codes</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {offers.map(offer => (
          <div 
            key={offer.code}
            className={`rounded-2xl p-4 bg-gradient-to-r ${offer.color} text-white shadow-md relative overflow-hidden flex flex-col justify-between`}
          >
            {/* Background Pattern */}
            <div className="absolute right-[-10%] top-[-20%] w-28 h-28 bg-white/10 rounded-full blur-xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="px-2.5 py-0.5 rounded-full bg-black/20 text-[10px] font-black uppercase tracking-wider text-white">
                  Limited Period
                </span>
                <Tag className="w-4 h-4 text-white/80" />
              </div>
              <h3 className="font-black text-lg">{offer.title}</h3>
              <p className="text-xs text-white/90 mt-1">{offer.desc}</p>
            </div>

            <div className="mt-4 pt-3 border-t border-white/20 flex items-center justify-between">
              <span className="font-mono font-bold text-xs bg-black/30 px-2.5 py-1 rounded-lg tracking-wider border border-white/20">
                {offer.code}
              </span>
              <button
                onClick={() => handleApply(offer.code)}
                className="px-3 py-1.5 rounded-lg bg-white text-slate-900 hover:bg-slate-100 text-xs font-bold shadow-xs transition-colors flex items-center gap-1 cursor-pointer"
              >
                {copiedCode === offer.code ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Applied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Apply Code</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

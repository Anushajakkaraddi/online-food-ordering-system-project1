import React, { useState } from 'react';
import { 
  Star, Clock, MapPin, Phone, Search, Filter, 
  ArrowLeft, Heart, ShieldCheck, Sparkles, Check 
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FoodCard } from './FoodCard';

export const RestaurantDetailView: React.FC = () => {
  const { 
    selectedRestaurantId, restaurantsList, foodItemsList, 
    setCurrentView, favoriteRestaurants, toggleFavoriteRestaurant 
  } = useApp();

  const [menuSearch, setMenuSearch] = useState('');
  const [selectedMenuCategory, setSelectedMenuCategory] = useState<string | null>(null);
  const [isVegOnly, setIsVegOnly] = useState(false);

  const restaurant = restaurantsList.find(r => r.id === selectedRestaurantId) || restaurantsList[0];
  const isFav = favoriteRestaurants.includes(restaurant.id);

  // Filter food items for this restaurant
  let menuItems = foodItemsList.filter(f => f.restaurantId === restaurant.id);

  if (menuSearch.trim()) {
    const q = menuSearch.toLowerCase();
    menuItems = menuItems.filter(f => f.name.toLowerCase().includes(q) || f.description.toLowerCase().includes(q));
  }

  if (isVegOnly) {
    menuItems = menuItems.filter(f => f.type === 'veg');
  }

  if (selectedMenuCategory) {
    menuItems = menuItems.filter(f => f.category.toLowerCase() === selectedMenuCategory.toLowerCase());
  }

  // Get list of categories in this restaurant's menu
  const availableCategories = Array.from(new Set(
    foodItemsList.filter(f => f.restaurantId === restaurant.id).map(f => f.category)
  ));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Back button */}
      <button
        onClick={() => setCurrentView('restaurants')}
        className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors cursor-pointer w-fit"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Restaurants</span>
      </button>

      {/* Restaurant Header Banner Card */}
      <div className="relative rounded-3xl overflow-hidden bg-slate-900 text-white shadow-xl border border-slate-800">
        
        <div className="h-48 sm:h-64 relative">
          <img
            src={restaurant.banner}
            alt={restaurant.name}
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

          {/* Bookmark Button */}
          <button
            onClick={() => toggleFavoriteRestaurant(restaurant.id)}
            className="absolute top-4 right-4 p-2.5 rounded-full bg-white/20 backdrop-blur-md hover:bg-white text-white hover:text-slate-900 transition-all cursor-pointer"
          >
            <Heart className={`w-5 h-5 ${isFav ? 'fill-rose-600 text-rose-600' : ''}`} />
          </button>
        </div>

        {/* Content Bar */}
        <div className="p-6 sm:p-8 -mt-20 relative z-10 flex flex-col sm:flex-row gap-6 items-start sm:items-end justify-between">
          
          <div className="flex gap-4 items-end">
            <img
              src={restaurant.logo}
              alt={restaurant.name}
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover ring-4 ring-white/20 shadow-2xl shrink-0 bg-white"
            />

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-none">
                  {restaurant.name}
                </h1>
                {restaurant.isPureVeg && (
                  <span className="bg-emerald-600 text-white font-extrabold text-[10px] uppercase px-2 py-0.5 rounded-md">
                    Pure Veg
                  </span>
                )}
              </div>

              <p className="text-slate-300 text-xs sm:text-sm font-medium mt-1">
                {restaurant.cuisines.join(' • ')}
              </p>

              <div className="flex items-center gap-3 mt-2 text-xs text-slate-300 font-medium">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-rose-400" />
                  {restaurant.address}
                </span>
                <span>•</span>
                <span>{restaurant.openingHours}</span>
              </div>
            </div>
          </div>

          {/* Stats Badges */}
          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/10 shrink-0">
            <div className="text-center pr-3 border-r border-white/20">
              <div className="flex items-center gap-1 text-emerald-400 font-black text-base">
                <span>{restaurant.rating}</span>
                <Star className="w-4 h-4 fill-emerald-400" />
              </div>
              <span className="text-[10px] text-slate-300 font-semibold">{restaurant.reviewCount}+ reviews</span>
            </div>

            <div className="text-center pl-1">
              <span className="block text-base font-black text-white">{restaurant.deliveryTimeMinutes} mins</span>
              <span className="text-[10px] text-slate-300 font-semibold">Delivery Time</span>
            </div>
          </div>

        </div>

      </div>

      {/* Menu Navigation & Search Bar */}
      <div className="sticky top-20 z-30 bg-white/95 backdrop-blur-md p-3.5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-center justify-between">
        
        {/* Category Pills Scroll */}
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
          <button
            onClick={() => setSelectedMenuCategory(null)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors shrink-0 cursor-pointer ${
              selectedMenuCategory === null ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Menu
          </button>
          {availableCategories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedMenuCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors shrink-0 cursor-pointer ${
                selectedMenuCategory === cat ? 'bg-rose-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Veg Only Switch & Search */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          
          {/* Veg Only Toggle */}
          <button
            onClick={() => setIsVegOnly(!isVegOnly)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-extrabold border transition-colors cursor-pointer ${
              isVegOnly ? 'bg-emerald-50 border-emerald-500 text-emerald-800' : 'bg-slate-50 border-slate-200 text-slate-600'
            }`}
          >
            <div className="w-3.5 h-3.5 border-2 border-emerald-600 flex items-center justify-center p-0.5 rounded-xs">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
            </div>
            <span>Veg Only</span>
          </button>

          {/* Search Input */}
          <div className="relative flex-1 md:w-56">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search in menu..."
              value={menuSearch}
              onChange={(e) => setMenuSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-100 text-xs font-medium focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500 border border-slate-200"
            />
          </div>

        </div>

      </div>

      {/* Menu Items Grid */}
      {menuItems.length === 0 ? (
        <div className="py-12 text-center bg-white rounded-3xl border border-slate-200">
          <p className="text-slate-500 font-bold text-sm">No items found matching your filters.</p>
          <button
            onClick={() => {
              setMenuSearch('');
              setSelectedMenuCategory(null);
              setIsVegOnly(false);
            }}
            className="mt-3 text-xs font-bold text-rose-600 underline cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
          {menuItems.map(item => (
            <FoodCard key={item.id} foodItem={item} />
          ))}
        </div>
      )}

    </div>
  );
};

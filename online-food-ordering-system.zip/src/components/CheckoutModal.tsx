import React, { useState } from 'react';
import { 
  ArrowLeft, MapPin, CreditCard, Wallet, Smartphone, ShieldCheck, 
  Plus, Check, Sparkles, Clock, AlertCircle, Building2, CheckCircle2 
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Address, PaymentMethod } from '../types';
import confetti from 'canvas-confetti';

export const CheckoutModal: React.FC = () => {
  const { 
    cartItems, cartSubtotal, appliedCoupon, couponDiscount, 
    deliveryTip, orderInstructions, addresses, setAddresses,
    selectedAddress, setSelectedAddress, placeOrder, setCurrentView,
    restaurantsList, currentUser
  } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('razorpay');
  const [isAddingNewAddress, setIsAddingNewAddress] = useState(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'idle' | 'processing' | 'success'>('idle');

  // New Address Form State
  const [newAddrTitle, setNewAddrTitle] = useState<'Home' | 'Work' | 'Other'>('Home');
  const [newFlatNo, setNewFlatNo] = useState('');
  const [newArea, setNewArea] = useState('');
  const [newLandmark, setNewLandmark] = useState('');
  const [newCity, setNewCity] = useState('Metro City');
  const [newPincode, setNewPincode] = useState('400018');

  // Card Form State
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8812');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('892');

  const restaurant = restaurantsList.find(r => r.id === (cartItems[0]?.restaurantId || 'rest_1')) || restaurantsList[0];
  const deliveryFee = cartSubtotal >= 25 ? 0 : (restaurant.deliveryFee || 1.99);
  const packagingFee = cartItems.length > 0 ? 1.00 : 0;
  const taxAmount = Number((cartSubtotal * 0.08).toFixed(2));
  const grandTotal = Math.max(0, Number((cartSubtotal + deliveryFee + packagingFee + taxAmount - couponDiscount + deliveryTip).toFixed(2)));

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFlatNo || !newArea) return;

    const newAddr: Address = {
      id: `addr_${Date.now()}`,
      userId: currentUser.id,
      title: newAddrTitle,
      flatNo: newFlatNo,
      area: newArea,
      landmark: newLandmark,
      city: newCity,
      pincode: newPincode,
      isDefault: false,
    };

    setAddresses(prev => [...prev, newAddr]);
    setSelectedAddress(newAddr);
    setIsAddingNewAddress(false);
  };

  const handlePlaceOrderSubmit = async () => {
    if (!selectedAddress) {
      alert('Please select or add a delivery address first.');
      return;
    }

    setIsProcessingPayment(true);
    setPaymentStep('processing');

    // Simulate Payment Gateway Network Call
    setTimeout(async () => {
      setPaymentStep('success');
      
      // Trigger Celebration Confetti
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (err) {
        // Fallback
      }

      const order = await placeOrder(paymentMethod, selectedAddress);
      
      setTimeout(() => {
        setIsProcessingPayment(false);
        setCurrentView('order_tracking');
      }, 1200);

    }, 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      
      {/* Header back button */}
      <div className="flex items-center gap-3 mb-6">
        <button
          onClick={() => setCurrentView('home')}
          className="p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">Checkout</h1>
          <p className="text-xs sm:text-sm text-slate-500">Confirm delivery address and payment details</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        
        {/* Left Column: Address & Payment Method */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Section 1: Delivery Address */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-orange-500" />
                <h3 className="font-extrabold text-slate-900 text-base">Select Delivery Address</h3>
              </div>
              <button
                onClick={() => setIsAddingNewAddress(!isAddingNewAddress)}
                className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>{isAddingNewAddress ? 'Cancel' : 'Add New Address'}</span>
              </button>
            </div>

            {/* Add Address Form */}
            {isAddingNewAddress && (
              <form onSubmit={handleSaveAddress} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex gap-2">
                  {(['Home', 'Work', 'Other'] as const).map(tag => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => setNewAddrTitle(tag)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        newAddrTitle === tag ? 'bg-orange-500 text-white border-orange-500' : 'bg-white border-slate-200 text-slate-700'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Flat / House No. / Building"
                    value={newFlatNo}
                    onChange={(e) => setNewFlatNo(e.target.value)}
                    required
                    className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                  <input
                    type="text"
                    placeholder="Area / Street Name"
                    value={newArea}
                    onChange={(e) => setNewArea(e.target.value)}
                    required
                    className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                  <input
                    type="text"
                    placeholder="Landmark (Optional)"
                    value={newLandmark}
                    onChange={(e) => setNewLandmark(e.target.value)}
                    className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                  <input
                    type="text"
                    placeholder="Pincode"
                    value={newPincode}
                    onChange={(e) => setNewPincode(e.target.value)}
                    required
                    className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-xs transition-colors cursor-pointer"
                >
                  Save & Deliver Here
                </button>
              </form>
            )}

            {/* Saved Addresses Cards */}
            <div className="grid sm:grid-cols-2 gap-3">
              {addresses.map(addr => {
                const isSelected = selectedAddress?.id === addr.id;

                return (
                  <div
                    key={addr.id}
                    onClick={() => setSelectedAddress(addr)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer relative ${
                      isSelected 
                        ? 'bg-orange-50/50 border-orange-500 text-slate-900 shadow-xs' 
                        : 'bg-white border-slate-200 hover:border-slate-300 text-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-extrabold text-xs uppercase tracking-wider text-orange-600 bg-orange-100/80 px-2 py-0.5 rounded-md">
                        {addr.title}
                      </span>
                      {isSelected && (
                        <CheckCircle2 className="w-4 h-4 text-orange-500" />
                      )}
                    </div>
                    <p className="font-bold text-xs text-slate-900">{addr.flatNo}</p>
                    <p className="text-xs text-slate-500 mt-0.5 leading-snug">{addr.area}, {addr.city} - {addr.pincode}</p>
                  </div>
                );
              })}
            </div>

          </div>

          {/* Section 2: Payment Gateway Selection */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
            <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-600" />
                <h3 className="font-extrabold text-slate-900 text-base">Select Payment Gateway</h3>
              </div>
              <span className="text-[10px] font-bold uppercase text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> 256-Bit SSL Encrypted
              </span>
            </div>

            {/* Payment Options Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              
              {[
                { id: 'razorpay', label: 'Razorpay', icon: '💳', desc: 'UPI, Cards & NetBanking' },
                { id: 'upi', label: 'UPI / QR', icon: '📱', desc: 'GPay, PhonePe, Paytm' },
                { id: 'stripe', label: 'Credit Card', icon: '💳', desc: 'Visa, Mastercard, Amex' },
                { id: 'paypal', label: 'PayPal', icon: '🅿️', desc: 'Instant Paypal Balance' },
                { id: 'cod', label: 'Cash on Delivery', icon: '💵', desc: 'Pay Cash at door' },
                { id: 'wallet', label: 'Hunger Wallet', icon: '👛', desc: `$${currentUser.walletBalance}` },
              ].map(method => {
                const isSelected = paymentMethod === method.id;

                return (
                  <div
                    key={method.id}
                    onClick={() => setPaymentMethod(method.id as PaymentMethod)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between text-left ${
                      isSelected
                        ? 'bg-orange-500 border-orange-500 text-white shadow-xs'
                        : 'bg-white border-slate-200 hover:border-slate-300 text-slate-800'
                    }`}
                  >
                    <div>
                      <span className="text-xl">{method.icon}</span>
                      <h4 className="font-extrabold text-xs mt-2">{method.label}</h4>
                      <p className={`text-[10px] mt-0.5 ${isSelected ? 'text-orange-100' : 'text-slate-400'}`}>
                        {method.desc}
                      </p>
                    </div>

                    <div className="mt-3 flex justify-end">
                      <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        isSelected ? 'bg-white border-white text-orange-500' : 'border-slate-300'
                      }`}>
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                    </div>
                  </div>
                );
              })}

            </div>

            {/* Extra Interactive Form based on method */}
            {paymentMethod === 'stripe' && (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <p className="text-xs font-bold text-slate-800">Enter Card Details</p>
                <div className="space-y-2">
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    placeholder="Card Number"
                    className="w-full px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-mono"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      placeholder="MM/YY"
                      className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-mono"
                    />
                    <input
                      type="password"
                      value={cardCvc}
                      onChange={(e) => setCardCvc(e.target.value)}
                      placeholder="CVC"
                      className="px-3 py-2 rounded-xl bg-white border border-slate-200 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {paymentMethod === 'upi' && (
              <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 flex items-center gap-4">
                <div className="w-20 h-20 bg-white p-2 rounded-xl border border-amber-300 flex items-center justify-center font-bold text-[10px] text-center text-slate-700">
                  [Simulated UPI QR Code]
                </div>
                <div>
                  <h5 className="font-extrabold text-xs text-amber-950">Scan QR Code or Enter VPA</h5>
                  <p className="text-[11px] text-slate-600 mt-1">Payable VPA: <span className="font-mono font-bold">crave.express@upi</span></p>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* Right Column: Order Summary & Place Order Action */}
        <div className="lg:col-span-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-lg space-y-4 sticky top-28">
            <h3 className="font-extrabold text-slate-900 text-base border-b border-slate-100 pb-3">
              Order Summary
            </h3>

            {/* Restaurant */}
            <div className="flex items-center gap-3 bg-slate-50 p-2.5 rounded-2xl">
              <img
                src={restaurant.banner}
                alt={restaurant.name}
                className="w-10 h-10 rounded-xl object-cover"
              />
              <div className="min-w-0">
                <h4 className="font-bold text-xs text-slate-900 truncate">{restaurant.name}</h4>
                <p className="text-[10px] text-slate-500">{cartItems.length} Items</p>
              </div>
            </div>

            {/* Items Brief */}
            <div className="space-y-1.5 max-h-40 overflow-y-auto divide-y divide-slate-100 text-xs">
              {cartItems.map(item => (
                <div key={item.id} className="pt-1.5 flex justify-between">
                  <span className="text-slate-700 font-medium truncate max-w-[180px]">
                    {item.quantity}× {item.foodItem.name}
                  </span>
                  <span className="font-bold text-slate-900">${item.itemTotal.toFixed(2)}</span>
                </div>
              ))}
            </div>

            {/* Bill Summary */}
            <div className="pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Items Subtotal</span>
                <span className="font-bold text-slate-900">${cartSubtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Charge</span>
                <span className="font-bold text-slate-900">${deliveryFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Packaging & Govt Tax</span>
                <span className="font-bold text-slate-900">${(packagingFee + taxAmount).toFixed(2)}</span>
              </div>
              {couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-600 font-bold">
                  <span>Discount</span>
                  <span>-${couponDiscount.toFixed(2)}</span>
                </div>
              )}
              {deliveryTip > 0 && (
                <div className="flex justify-between">
                  <span>Delivery Tip</span>
                  <span className="font-bold text-slate-900">${deliveryTip.toFixed(2)}</span>
                </div>
              )}

              <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-sm font-black text-slate-900">
                <span>Final Payable</span>
                <span className="text-orange-600 text-base">${grandTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Place Order Button */}
            <button
              onClick={handlePlaceOrderSubmit}
              disabled={isProcessingPayment}
              className="w-full py-3.5 rounded-2xl bg-orange-500 hover:bg-orange-600 text-white font-black text-sm shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98 disabled:opacity-60"
            >
              {isProcessingPayment ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Authorizing Gateway...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-white" />
                  <span>Pay ${grandTotal.toFixed(2)} & Place Order</span>
                </>
              )}
            </button>

            <p className="text-[10px] text-slate-400 text-center leading-tight">
              By placing order, you agree to CraveCraft's Terms of Service & Privacy Policy.
            </p>

          </div>
        </div>

      </div>

    </div>
  );
};

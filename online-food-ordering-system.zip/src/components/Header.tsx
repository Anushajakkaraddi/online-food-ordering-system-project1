import React, { useState } from 'react';
import { 
  UtensilsCrossed, MapPin, Search, ShoppingBag, Heart, User as UserIcon, 
  Bell, Shield, ChevronDown, Sparkles, LogOut, FileText, CheckCircle2, Store
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UserRole } from '../types';

export const Header: React.FC = () => {
  const { 
    currentView, setCurrentView, 
    currentUser, userRole, setUserRole,
    selectedAddress, setIsLocationModalOpen,
    cartItems, cartSubtotal, setIsCartDrawerOpen,
    wishlist, notifications, markNotificationRead,
    setIsAuthModalOpen, setIsDocumentationModalOpen,
    searchQuery, setSearchQuery
  } = useApp();

  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isNotifMenuOpen, setIsNotifMenuOpen] = useState(false);
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);

  const cartItemCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const unreadNotifCount = notifications.filter(n => !n.isRead).length;

  const handleRoleChange = (role: UserRole) => {
    setUserRole(role);
    setIsRoleDropdownOpen(false);
    if (role === 'admin' || role === 'restaurant_owner') {
      setCurrentView('admin_dashboard');
    } else {
      setCurrentView('home');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          
          {/* Brand Logo & Tagline */}
          <div className="flex items-center gap-6">
            <button 
              onClick={() => setCurrentView('home')} 
              className="flex items-center gap-2.5 group cursor-pointer text-left focus:outline-none"
            >
              <div className="w-10 h-10 rounded-xl bg-orange-500 flex items-center justify-center text-white shadow-sm group-hover:bg-orange-600 transition-colors">
                <UtensilsCrossed className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xl font-black tracking-tight text-slate-900">
                  CraveCraft
                </span>
                <span className="block text-[10px] font-bold uppercase tracking-wider text-orange-600">
                  Online Food System
                </span>
              </div>
            </button>

            {/* Location Selector */}
            <button
              onClick={() => setIsLocationModalOpen(true)}
              className="hidden md:flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200/80 text-slate-700 text-xs font-semibold transition-colors border border-slate-200/80 max-w-[220px] truncate"
            >
              <MapPin className="w-3.5 h-3.5 text-orange-500 shrink-0" />
              <div className="text-left truncate">
                <span className="block text-[10px] text-slate-500 font-normal leading-tight">Deliver To</span>
                <span className="truncate block">{selectedAddress ? `${selectedAddress.title}: ${selectedAddress.area}` : 'Select Location'}</span>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0 ml-auto" />
            </button>
          </div>

          {/* Search Input Bar */}
          <div className="hidden lg:flex flex-1 max-w-md mx-4 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search for restaurants, dishes, or cuisines..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (currentView !== 'restaurants' && currentView !== 'home') {
                  setCurrentView('restaurants');
                }
              }}
              className="w-full pl-10 pr-4 py-2 rounded-full bg-slate-100 text-slate-800 text-xs font-medium placeholder:text-slate-400 border border-slate-200 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all"
            />
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* System Docs button for BCA Final Year Project */}
            <button
              onClick={() => setIsDocumentationModalOpen(true)}
              className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200 text-xs font-semibold transition-colors cursor-pointer"
              title="View BCA Project Documentation & ER Diagram"
            >
              <FileText className="w-4 h-4 text-amber-600" />
              <span>Project Specs</span>
            </button>

            {/* Role Switcher Badge */}
            <div className="relative">
              <button
                onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                  userRole === 'admin' 
                    ? 'bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100' 
                    : userRole === 'restaurant_owner'
                    ? 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100'
                    : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                }`}
              >
                {userRole === 'admin' && <Shield className="w-3.5 h-3.5 text-purple-600" />}
                {userRole === 'restaurant_owner' && <Store className="w-3.5 h-3.5 text-blue-600" />}
                {userRole === 'customer' && <UserIcon className="w-3.5 h-3.5 text-emerald-600" />}
                <span className="capitalize">{userRole.replace('_', ' ')}</span>
                <ChevronDown className="w-3 h-3 opacity-60" />
              </button>

              {isRoleDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-100 py-1.5 z-50 animate-in fade-in slide-in-from-top-2">
                  <div className="px-3 py-1.5 text-[10px] font-extrabold uppercase text-slate-400 tracking-wider">
                    Switch Active Persona
                  </div>
                  <button
                    onClick={() => handleRoleChange('customer')}
                    className="w-full flex items-center justify-between px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    <span>Customer View</span>
                    {userRole === 'customer' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                  </button>
                  <button
                    onClick={() => handleRoleChange('restaurant_owner')}
                    className="w-full flex items-center justify-between px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    <span>Restaurant Owner</span>
                    {userRole === 'restaurant_owner' && <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />}
                  </button>
                  <button
                    onClick={() => handleRoleChange('admin')}
                    className="w-full flex items-center justify-between px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                  >
                    <span>System Admin</span>
                    {userRole === 'admin' && <CheckCircle2 className="w-3.5 h-3.5 text-purple-600" />}
                  </button>
                </div>
              )}
            </div>

            {/* Notifications Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsNotifMenuOpen(!isNotifMenuOpen)}
                className="p-2.5 rounded-full hover:bg-slate-100 text-slate-600 relative transition-colors cursor-pointer"
              >
                <Bell className="w-5 h-5" />
                {unreadNotifCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-orange-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
                    {unreadNotifCount}
                  </span>
                )}
              </button>

              {isNotifMenuOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-100 py-3 z-50">
                  <div className="px-4 pb-2 border-b border-slate-100 flex items-center justify-between">
                    <span className="font-bold text-slate-800 text-sm">Notifications</span>
                    <span className="text-[10px] font-semibold text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full">
                      {unreadNotifCount} New
                    </span>
                  </div>
                  <div className="max-h-64 overflow-y-auto divide-y divide-slate-50">
                    {notifications.length === 0 ? (
                      <p className="p-4 text-xs text-slate-400 text-center">No notifications yet.</p>
                    ) : (
                      notifications.map(n => (
                        <div 
                          key={n.id}
                          onClick={() => markNotificationRead(n.id)}
                          className={`p-3 text-xs transition-colors cursor-pointer hover:bg-slate-50 ${!n.isRead ? 'bg-orange-50/40' : ''}`}
                        >
                          <div className="font-bold text-slate-800 flex items-center justify-between">
                            <span>{n.title}</span>
                            <span className="text-[10px] font-normal text-slate-400">{n.createdAt}</span>
                          </div>
                          <p className="text-slate-600 mt-1 leading-snug">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Wishlist Icon */}
            <button
              onClick={() => setCurrentView('customer_dashboard')}
              className="p-2.5 rounded-full hover:bg-slate-100 text-slate-600 relative transition-colors cursor-pointer hidden sm:flex"
              title="View Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-slate-900 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Drawer Trigger */}
            <button
              onClick={() => setIsCartDrawerOpen(true)}
              className="flex items-center gap-2.5 px-4 py-2 rounded-full bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-sm active:scale-95 transition-all cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Cart</span>
              <span className="bg-white/20 px-2 py-0.5 rounded-full text-[11px] font-extrabold">
                {cartItemCount}
              </span>
              {cartSubtotal > 0 && (
                <span className="hidden md:inline font-black border-l border-white/20 pl-2">
                  ${cartSubtotal.toFixed(2)}
                </span>
              )}
            </button>

            {/* User Profile Dropdown */}
            <div className="relative ml-1">
              <button
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                className="flex items-center gap-2 p-1 rounded-full hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <img
                  src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150'}
                  alt={currentUser.name}
                  className="w-9 h-9 rounded-full object-cover ring-2 ring-rose-500/30"
                />
              </button>

              {isProfileMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-2xl border border-slate-100 py-2 z-50">
                  <div className="px-4 py-2 border-b border-slate-100">
                    <p className="font-bold text-slate-800 text-xs truncate">{currentUser.name}</p>
                    <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                  </div>
                  <div className="py-1">
                    <button
                      onClick={() => {
                        setCurrentView('customer_dashboard');
                        setIsProfileMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 hover:bg-rose-50 hover:text-rose-600 transition-colors"
                    >
                      Customer Dashboard
                    </button>
                    {(userRole === 'admin' || userRole === 'restaurant_owner') && (
                      <button
                        onClick={() => {
                          setCurrentView('admin_dashboard');
                          setIsProfileMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs font-semibold text-purple-700 hover:bg-purple-50 transition-colors"
                      >
                        Admin Control Panel
                      </button>
                    )}
                    <button
                      onClick={() => {
                        setIsDocumentationModalOpen(true);
                        setIsProfileMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 transition-colors"
                    >
                      BCA Project Specs & ER Diagram
                    </button>
                  </div>
                  <div className="pt-1 border-t border-slate-100">
                    <button
                      onClick={() => {
                        setIsAuthModalOpen(true);
                        setIsProfileMenuOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 text-xs font-bold text-rose-600 hover:bg-rose-50 transition-colors flex items-center gap-2"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      Sign Out / Switch Account
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>
      </div>
    </header>
  );
};

import React from 'react';
import { useApp } from '../context/AppContext';
import { Utensils } from 'lucide-react';

export const CategoryBar: React.FC = () => {
  const { categoriesList, selectedCategory, setSelectedCategory, setCurrentView } = useApp();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Explore Food Categories
          </h2>
          <p className="text-slate-500 text-xs sm:text-sm mt-0.5">
            What are you craving today? Select from our curated food menus
          </p>
        </div>

        {selectedCategory && (
          <button
            onClick={() => setSelectedCategory(null)}
            className="text-xs font-bold text-orange-600 hover:text-orange-700 bg-orange-50 px-3 py-1.5 rounded-full border border-orange-200 transition-colors cursor-pointer"
          >
            Clear Filter ×
          </button>
        )}
      </div>

      {/* Grid of Categories */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5 sm:gap-4">
        {categoriesList.map(cat => {
          const isSelected = selectedCategory?.toLowerCase() === cat.name.toLowerCase();

          return (
            <div
              key={cat.id}
              onClick={() => {
                if (isSelected) {
                  setSelectedCategory(null);
                } else {
                  setSelectedCategory(cat.name);
                  setCurrentView('restaurants');
                }
              }}
              className={`group relative overflow-hidden rounded-2xl p-3 border transition-all cursor-pointer flex flex-col items-center text-center ${
                isSelected
                  ? 'bg-orange-500 border-orange-500 text-white shadow-md scale-[1.02]'
                  : 'bg-white border-slate-200/80 hover:border-orange-400 hover:shadow-xs text-slate-800'
              }`}
            >
              {/* Category Image */}
              <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden mb-2.5 shadow-xs">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors" />
                <span className="absolute bottom-1 right-1 text-base bg-white/90 backdrop-blur-xs px-1 rounded-md shadow-xs">
                  {cat.icon}
                </span>
              </div>

              {/* Category Name & Count */}
              <h3 className={`font-bold text-xs sm:text-sm truncate w-full ${isSelected ? 'text-white' : 'text-slate-900'}`}>
                {cat.name}
              </h3>
              <span className={`text-[10px] font-medium mt-0.5 ${isSelected ? 'text-orange-100' : 'text-slate-400'}`}>
                {cat.itemCount} items
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

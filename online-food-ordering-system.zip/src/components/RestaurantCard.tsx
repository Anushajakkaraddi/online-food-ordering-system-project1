import React from 'react';
import { Star, Clock, Heart, ShieldCheck, MapPin } from 'lucide-react';
import { Restaurant } from '../types';
import { useApp } from '../context/AppContext';

interface RestaurantCardProps {
  restaurant: Restaurant;
}

export const RestaurantCard: React.FC<RestaurantCardProps> = ({ restaurant }) => {
  const { 
    setSelectedRestaurantId, setCurrentView, 
    favoriteRestaurants, toggleFavoriteRestaurant 
  } = useApp();

  const isFav = favoriteRestaurants.includes(restaurant.id);

  const handleClick = () => {
    setSelectedRestaurantId(restaurant.id);
    setCurrentView('restaurant_detail');
  };

  return (
    <div className="group bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md hover:border-orange-300 transition-all duration-300 flex flex-col overflow-hidden cursor-pointer">
      
      {/* Banner Image Container */}
      <div className="relative h-44 sm:h-48 overflow-hidden bg-slate-100" onClick={handleClick}>
        <img
          src={restaurant.banner}
          alt={restaurant.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none">
          
          <div className="flex gap-1.5 flex-wrap">
            {restaurant.isPromoted && (
              <span className="bg-slate-900/90 text-orange-400 border border-orange-400/30 font-bold text-[10px] uppercase px-2 py-0.5 rounded-md tracking-wider">
                Promoted
              </span>
            )}
            {restaurant.isPureVeg && (
              <span className="bg-emerald-600 text-white font-bold text-[10px] uppercase px-2 py-0.5 rounded-md tracking-wider flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-white rounded-full"></span> Pure Veg
              </span>
            )}
          </div>

          {/* Bookmark Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleFavoriteRestaurant(restaurant.id);
            }}
            className="pointer-events-auto p-2 rounded-full bg-white/90 hover:bg-white text-slate-700 shadow-sm transition-colors cursor-pointer"
            title={isFav ? "Remove from Favorites" : "Add to Favorites"}
          >
            <Heart className={`w-4 h-4 ${isFav ? 'fill-orange-500 text-orange-500' : 'text-slate-600'}`} />
          </button>
        </div>

        {/* Bottom Banner Badge: Offer Tag & Delivery Fee */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-white text-xs font-bold">
          {restaurant.discountBadge ? (
            <span className="bg-orange-500 backdrop-blur-xs px-2.5 py-1 rounded-lg text-[11px] font-black uppercase tracking-wide">
              {restaurant.discountBadge}
            </span>
          ) : (
            <span className="text-slate-300 text-[11px]">Best Gourmet Taste</span>
          )}

          <div className="flex items-center gap-1 bg-black/60 backdrop-blur-xs px-2 py-1 rounded-lg text-[11px] font-medium text-slate-200">
            <Clock className="w-3 h-3 text-orange-400" />
            <span>{restaurant.deliveryTimeMinutes} mins</span>
          </div>
        </div>
      </div>

      {/* Info Card Content */}
      <div className="p-4 flex-1 flex flex-col justify-between" onClick={handleClick}>
        
        <div>
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-extrabold text-slate-900 text-base leading-tight group-hover:text-orange-600 transition-colors line-clamp-1">
              {restaurant.name}
            </h3>

            {/* Rating Badge */}
            <div className="flex items-center gap-1 bg-emerald-700 text-white font-bold text-xs px-2 py-0.5 rounded-md shrink-0 shadow-xs">
              <span>{restaurant.rating}</span>
              <Star className="w-3 h-3 fill-white" />
            </div>
          </div>

          {/* Cuisines */}
          <p className="text-slate-500 text-xs font-medium mt-1 truncate">
            {restaurant.cuisines.join(' • ')}
          </p>
        </div>

        {/* Price for two & Location */}
        <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-600">
          <div className="flex items-center gap-1 text-slate-500">
            <MapPin className="w-3.5 h-3.5 text-slate-400" />
            <span className="truncate max-w-[140px]">{restaurant.address}</span>
          </div>
          <span className="font-bold text-slate-900">
            ${restaurant.avgCostForTwo} for two
          </span>
        </div>

      </div>

    </div>
  );
};

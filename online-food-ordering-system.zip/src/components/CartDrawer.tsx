import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, Tag, ShoppingBag, ArrowRight, Sparkles, Check, Info } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CartDrawer: React.FC = () => {
  const { 
    isCartDrawerOpen, setIsCartDrawerOpen,
    cartItems, removeFromCart, updateCartQuantity, clearCart,
    cartSubtotal, appliedCoupon, couponDiscount, applyCoupon, removeCoupon,
    deliveryTip, setDeliveryTip, orderInstructions, setOrderInstructions,
    setCurrentView, setSelectedAddress, addresses, restaurantsList
  } = useApp();

  const [couponInput, setCouponInput] = useState('');
  const [couponMessage, setCouponMessage] = useState<{ success: boolean; text: string } | null>(null);

  if (!isCartDrawerOpen) return null;

  const restaurant = restaurantsList.find(r => r.id === (cartItems[0]?.restaurantId || 'rest_1')) || restaurantsList[0];
  const deliveryFee = cartSubtotal >= 25 ? 0 : (restaurant.deliveryFee || 1.99);
  const packagingFee = cartItems.length > 0 ? 1.00 : 0;
  const taxAmount = Number((cartSubtotal * 0.08).toFixed(2));
  const grandTotal = Math.max(0, Number((cartSubtotal + deliveryFee + packagingFee + taxAmount - couponDiscount + deliveryTip).toFixed(2)));

  const handleApplyCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    const res = applyCoupon(couponInput);
    setCouponMessage({ success: res.success, text: res.message });
    if (res.success) {
      setCouponInput('');
    }
  };

  const handleProceedToCheckout = () => {
    setIsCartDrawerOpen(false);
    setCurrentView('checkout');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end animate-in fade-in">
      <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl overflow-hidden border-l border-slate-100">
        
        {/* Drawer Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-orange-500 text-white">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base leading-tight">Your Food Basket</h3>
              {cartItems.length > 0 && (
                <p className="text-[11px] text-slate-400 font-medium truncate max-w-[200px]">
                  From {cartItems[0].restaurantName}
                </p>
              )}
            </div>
          </div>

          <button
            onClick={() => setIsCartDrawerOpen(false)}
            className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        {cartItems.length === 0 ? (
          <div className="flex-1 p-6 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 rounded-full bg-orange-50 flex items-center justify-center text-orange-500 mb-4">
              <ShoppingBag className="w-10 h-10" />
            </div>
            <h4 className="font-extrabold text-slate-900 text-lg">Your basket is empty</h4>
            <p className="text-slate-500 text-xs mt-1 max-w-xs leading-relaxed">
              Explore delicious dishes from top local restaurants and start adding your favorites!
            </p>
            <button
              onClick={() => {
                setIsCartDrawerOpen(false);
                setCurrentView('restaurants');
              }}
              className="mt-6 px-6 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-extrabold text-xs shadow-sm transition-colors cursor-pointer"
            >
              Browse Menu
            </button>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            
            {/* Cart Items List */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-wider">
                <span>Items ({cartItems.reduce((acc, i) => acc + i.quantity, 0)})</span>
                <button
                  onClick={clearCart}
                  className="text-orange-600 hover:underline cursor-pointer"
                >
                  Clear All
                </button>
              </div>

              {cartItems.map(item => (
                <div 
                  key={item.id} 
                  className="p-3 rounded-2xl border border-slate-200/80 bg-slate-50/50 flex gap-3 items-start justify-between"
                >
                  <img
                    src={item.foodItem.image}
                    alt={item.foodItem.name}
                    className="w-14 h-14 rounded-xl object-cover shrink-0"
                  />

                  <div className="flex-1 min-w-0">
                    <h5 className="font-extrabold text-xs text-slate-900 truncate">
                      {item.foodItem.name}
                    </h5>

                    {item.selectedOptions.length > 0 && (
                      <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                        {item.selectedOptions.map(o => o.optionName).join(', ')}
                      </p>
                    )}

                    <div className="font-black text-xs text-slate-900 mt-1">
                      ${item.itemTotal.toFixed(2)}
                    </div>
                  </div>

                  {/* Quantity Controls */}
                  <div className="flex items-center gap-1.5 bg-white px-2 py-1 rounded-xl border border-slate-200 shadow-2xs">
                    <button
                      onClick={() => updateCartQuantity(item.id, -1)}
                      className="p-1 text-slate-600 hover:text-orange-600 transition-colors cursor-pointer"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="font-extrabold text-xs text-slate-900 w-3 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateCartQuantity(item.id, 1)}
                      className="p-1 text-slate-600 hover:text-orange-600 transition-colors cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Promo Code Coupon Box */}
            <div className="p-3.5 rounded-2xl bg-orange-50/60 border border-orange-200/60 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-900">
                <span className="flex items-center gap-1.5">
                  <Tag className="w-4 h-4 text-orange-600" /> Coupon & Promo Code
                </span>
                {appliedCoupon && (
                  <button
                    onClick={removeCoupon}
                    className="text-[10px] font-extrabold text-orange-600 hover:underline cursor-pointer"
                  >
                    Remove
                  </button>
                )}
              </div>

              {appliedCoupon ? (
                <div className="p-2.5 rounded-xl bg-white border border-orange-300 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono font-black text-slate-900">{appliedCoupon.code}</span>
                    <p className="text-[10px] text-emerald-700 font-semibold">{appliedCoupon.description}</p>
                  </div>
                  <span className="font-black text-emerald-600">-${couponDiscount.toFixed(2)}</span>
                </div>
              ) : (
                <form onSubmit={handleApplyCouponSubmit} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Enter CRAVE50 or WELCOME20"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-xs text-slate-900 font-medium focus:outline-none focus:ring-1 focus:ring-orange-500 uppercase"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-2xs transition-colors cursor-pointer"
                  >
                    Apply
                  </button>
                </form>
              )}

              {couponMessage && (
                <p className={`text-[11px] font-semibold ${couponMessage.success ? 'text-emerald-700' : 'text-orange-600'}`}>
                  {couponMessage.text}
                </p>
              )}
            </div>

            {/* Delivery Executive Tip */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-2">
                Tip Delivery Partner
              </label>
              <div className="flex gap-2">
                {[0, 1, 2, 5].map(amount => (
                  <button
                    key={amount}
                    type="button"
                    onClick={() => setDeliveryTip(amount)}
                    className={`flex-1 py-1.5 rounded-xl text-xs font-extrabold border transition-all cursor-pointer ${
                      deliveryTip === amount 
                        ? 'bg-orange-500 text-white border-orange-500 shadow-xs' 
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {amount === 0 ? 'No Tip' : `$${amount}`}
                  </button>
                ))}
              </div>
            </div>

            {/* Detailed Bill Summary */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
              <h5 className="font-extrabold text-slate-900 text-xs border-b border-slate-200 pb-2 uppercase tracking-wider">
                Bill Details
              </h5>

              <div className="flex justify-between text-slate-600">
                <span>Item Subtotal</span>
                <span className="font-bold text-slate-900">${cartSubtotal.toFixed(2)}</span>
              </div>

              <div className="flex justify-between text-slate-600">
                <span>Delivery Charge</span>
                {deliveryFee === 0 ? (
                  <span className="font-bold text-emerald-600">FREE</span>
                ) : (
                  <span className="font-bold text-slate-900">${deliveryFee.toFixed(2)}</span>
                )}
              </div>

              <div className="flex justify-between text-slate-600">
                <span>Packaging Fee</span>
                <span className="font-bold text-slate-900">${packagingFee.toFixed(2)}</span>
              </div>

              <div className="flex justify-between text-slate-600">
                <span>Taxes & Govt Charges (8%)</span>
                <span className="font-bold text-slate-900">${taxAmount.toFixed(2)}</span>
              </div>

              {couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 font-bold">
                  <span>Promo Discount</span>
                  <span>-${couponDiscount.toFixed(2)}</span>
                </div>
              )}

              {deliveryTip > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>Delivery Tip</span>
                  <span className="font-bold text-slate-900">${deliveryTip.toFixed(2)}</span>
                </div>
              )}

              <div className="pt-2 border-t border-slate-200 flex justify-between items-center text-sm font-black text-slate-900">
                <span>Grand Total</span>
                <span className="text-orange-600 text-base">${grandTotal.toFixed(2)}</span>
              </div>
            </div>

          </div>
        )}

        {/* Drawer Footer / Proceed Button */}
        {cartItems.length > 0 && (
          <div className="p-4 border-t border-slate-100 bg-white shadow-lg space-y-2">
            <button
              onClick={handleProceedToCheckout}
              className="w-full py-3.5 px-4 rounded-2xl bg-orange-500 hover:bg-orange-600 text-white font-black text-xs shadow-md flex items-center justify-between transition-all cursor-pointer active:scale-98"
            >
              <div>
                <span className="block text-[10px] text-orange-100 font-bold uppercase tracking-wider">Total Amount</span>
                <span className="text-base">${grandTotal.toFixed(2)}</span>
              </div>
              <div className="flex items-center gap-1.5 font-extrabold uppercase tracking-wide">
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </button>
          </div>
        )}

      </div>
    </div>
  );
};

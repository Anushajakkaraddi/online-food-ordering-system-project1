import React, { useState } from 'react';
import { Search, MapPin, Sparkles, Clock, ShieldCheck, Flame, Tag, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const HeroBanner: React.FC = () => {
  const { 
    searchQuery, setSearchQuery, 
    setCurrentView, setSelectedCategory, 
    setIsLocationModalOpen, selectedAddress,
    applyCoupon, setIsCartDrawerOpen 
  } = useApp();

  const [deliveryType, setDeliveryType] = useState<'delivery' | 'pickup'>('delivery');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setCurrentView('restaurants');
    }
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 text-white rounded-[2rem] my-4 mx-4 sm:mx-6 lg:mx-8 shadow-xl border border-slate-800">
      
      {/* Decorative Subtle Accent Orbs */}
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-slate-700/20 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-6 py-10 lg:py-14 grid lg:grid-cols-12 gap-8 items-center">
        
        {/* Left Hero Content */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-bold tracking-wide">
            <Sparkles className="w-3.5 h-3.5 text-orange-400" />
            <span>Fastest Gourmet Delivery in Metro City</span>
          </div>

          {/* Main Title */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
            Delicious Flavors <br />
            <span className="text-orange-500">
              Delivered To Your Doorstep
            </span>
          </h1>

          <p className="text-slate-300 text-sm sm:text-base max-w-xl leading-relaxed">
            Order from 50+ top-rated local restaurants, authentic cloud kitchens, and gourmet bakeries with real-time order tracking.
          </p>

          {/* Delivery / Pickup Tabs & Search Bar Card */}
          <div className="bg-slate-800/90 p-3.5 rounded-2xl border border-slate-700/80 shadow-lg max-w-xl backdrop-blur-xs">
            
            {/* Delivery/Pickup Toggle */}
            <div className="flex gap-2 mb-3 bg-slate-950/80 p-1 rounded-xl w-fit text-xs font-bold border border-slate-800">
              <button
                onClick={() => setDeliveryType('delivery')}
                className={`px-4 py-1.5 rounded-lg transition-all cursor-pointer ${
                  deliveryType === 'delivery' 
                    ? 'bg-orange-500 text-white shadow-xs' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Delivery
              </button>
              <button
                onClick={() => setDeliveryType('pickup')}
                className={`px-4 py-1.5 rounded-lg transition-all cursor-pointer ${
                  deliveryType === 'pickup' 
                    ? 'bg-orange-500 text-white shadow-xs' 
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Self Pickup
              </button>
            </div>

            {/* Combined Location & Search Form */}
            <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-2">
              
              <button
                type="button"
                onClick={() => setIsLocationModalOpen(true)}
                className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-950 text-slate-200 text-xs font-medium border border-slate-700/80 transition-colors text-left sm:max-w-[170px] truncate cursor-pointer"
              >
                <MapPin className="w-4 h-4 text-orange-500 shrink-0" />
                <span className="truncate">{selectedAddress ? selectedAddress.title : 'Select Location'}</span>
              </button>

              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Try 'Biryani', 'Pizza', 'Burger'..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-3 py-2.5 rounded-xl bg-white text-slate-900 placeholder:text-slate-400 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-black tracking-wide shadow-xs flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
              >
                <span>Find Food</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>

          {/* Quick Trending Tags */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
            <span className="text-slate-400 font-bold flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 text-orange-500" /> Trending:
            </span>
            {['Biryani', 'Pizza', 'Burger', 'Chinese', 'Desserts'].map(tag => (
              <button
                key={tag}
                onClick={() => {
                  setSelectedCategory(tag);
                  setCurrentView('restaurants');
                }}
                className="px-3 py-1 rounded-lg bg-slate-800/80 hover:bg-orange-500 hover:text-white text-slate-200 text-[11px] font-medium border border-slate-700/80 transition-all cursor-pointer"
              >
                {tag}
              </button>
            ))}
          </div>

        </div>

        {/* Right Offer Highlight Cards */}
        <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
          
          <div className="bg-gradient-to-br from-slate-800/90 to-slate-900/90 p-5 rounded-2xl border border-slate-700/80 relative overflow-hidden group hover:border-orange-500/50 transition-all shadow-md">
            <div className="flex items-start justify-between relative z-10">
              <div>
                <span className="inline-block px-2.5 py-0.5 rounded-full bg-orange-500 text-white font-black text-[10px] uppercase tracking-wider mb-2 shadow-2xs">
                  Special Offer
                </span>
                <h3 className="text-xl font-black text-white">50% OFF Up To $10</h3>
                <p className="text-xs text-slate-300 mt-1">Use Code: <span className="font-mono font-bold text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20">CRAVE50</span></p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-400 group-hover:scale-110 transition-transform">
                <Tag className="w-5 h-5" />
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-slate-800/90 to-slate-900/90 p-5 rounded-2xl border border-slate-700/80 relative overflow-hidden group hover:border-orange-500/50 transition-all shadow-md">
            <div className="flex items-start justify-between relative z-10">
              <div>
                <span className="inline-block px-2.5 py-0.5 rounded-full bg-slate-700 text-slate-200 font-black text-[10px] uppercase tracking-wider mb-2">
                  Free Delivery
                </span>
                <h3 className="text-xl font-black text-white">Zero Delivery Fee</h3>
                <p className="text-xs text-slate-300 mt-1">On orders above $25 across top restaurants</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-slate-700/40 flex items-center justify-center text-slate-300 group-hover:scale-110 transition-transform">
                <Clock className="w-5 h-5" />
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Trust Stats Bar */}
      <div className="border-t border-slate-800 bg-slate-950/60 px-6 py-4">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <span className="block text-lg font-black text-white">50+</span>
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Partner Restaurants</span>
          </div>
          <div>
            <span className="block text-lg font-black text-orange-400">10,000+</span>
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Happy Foodies</span>
          </div>
          <div>
            <span className="block text-lg font-black text-slate-200">25 Mins</span>
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Avg. Delivery Time</span>
          </div>
          <div>
            <span className="block text-lg font-black text-emerald-400">4.9 ★</span>
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Customer Rating</span>
          </div>
        </div>
      </div>

    </div>
  );
};

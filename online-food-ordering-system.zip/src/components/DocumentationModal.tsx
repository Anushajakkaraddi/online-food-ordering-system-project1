import React, { useState } from 'react';
import { X, Database, FileCode, Server, ShieldCheck, Layers, ArrowRight, Download, CheckCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const DocumentationModal: React.FC = () => {
  const { isDocumentationModalOpen, setIsDocumentationModalOpen } = useApp();
  const [activeTab, setActiveTab] = useState<'er_diagram' | 'schema' | 'architecture' | 'api' | 'security'>('er_diagram');

  if (!isDocumentationModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-5xl w-full max-h-[92vh] flex flex-col overflow-hidden shadow-2xl border border-slate-200">
        
        {/* Header */}
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500 text-slate-950 font-black">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-white tracking-tight">System Specification & ER Architecture</h2>
                <span className="bg-amber-400 text-slate-950 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full">
                  BCA Final Year Specs
                </span>
              </div>
              <p className="text-xs text-slate-400">Database Normalization (3NF), MVT Flow, Relational Models & REST APIs</p>
            </div>
          </div>

          <button
            onClick={() => setIsDocumentationModalOpen(false)}
            className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-slate-100 p-2 flex gap-2 border-b border-slate-200 overflow-x-auto scrollbar-none">
          {[
            { id: 'er_diagram', label: 'ER Diagram & Schema' },
            { id: 'schema', label: '3NF Database Tables' },
            { id: 'architecture', label: 'Django MVT Structure' },
            { id: 'api', label: 'API Documentation' },
            { id: 'security', label: 'Security & Deployment' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                activeTab === tab.id 
                  ? 'bg-slate-900 text-white shadow-xs' 
                  : 'text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 text-slate-800 text-xs">
          
          {/* ER Diagram View */}
          {activeTab === 'er_diagram' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-950">
                <h3 className="font-extrabold text-sm mb-1">Entity-Relationship Overview (3NF Normalized)</h3>
                <p className="leading-relaxed">
                  The CraveCraft database is designed up to 3rd Normal Form (3NF) to minimize data redundancy and enforce referential integrity across 16 interconnected relational entities.
                </p>
              </div>

              {/* Visual Entity Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  {
                    name: 'Users / CustomUser',
                    pk: 'id (UUID)',
                    fk: 'role_id -> Role',
                    rel: '1 : 1 with CustomerProfile, 1 : N with Orders & Reviews',
                    cols: ['email', 'password_hash', 'phone', 'is_verified', 'role', 'wallet_balance']
                  },
                  {
                    name: 'Restaurant',
                    pk: 'id (UUID)',
                    fk: 'owner_id -> Users',
                    rel: '1 : N with FoodItem & Orders, N : M with Category',
                    cols: ['name', 'slug', 'logo_url', 'rating', 'avg_cost_for_two', 'is_pure_veg', 'is_active']
                  },
                  {
                    name: 'FoodItem',
                    pk: 'id (UUID)',
                    fk: 'restaurant_id -> Restaurant, category_id -> FoodCategory',
                    rel: '1 : N with CartItem & OrderItem',
                    cols: ['name', 'description', 'price', 'discount_price', 'veg_non_veg', 'prep_time', 'is_available']
                  },
                  {
                    name: 'Order',
                    pk: 'id (UUID)',
                    fk: 'user_id -> Users, restaurant_id -> Restaurant, address_id -> Address',
                    rel: '1 : N with OrderItem, 1 : 1 with Payment',
                    cols: ['order_number', 'grand_total', 'order_status', 'payment_status', 'placed_at']
                  },
                  {
                    name: 'OrderItem',
                    pk: 'id (UUID)',
                    fk: 'order_id -> Order, food_item_id -> FoodItem',
                    rel: 'N : 1 with Order & FoodItem',
                    cols: ['quantity', 'unit_price', 'selected_customizations_json', 'item_total']
                  },
                  {
                    name: 'Payment',
                    pk: 'id (UUID)',
                    fk: 'order_id -> Order, user_id -> Users',
                    rel: '1 : 1 with Order',
                    cols: ['transaction_id', 'payment_gateway', 'amount', 'status', 'created_at']
                  },
                ].map(entity => (
                  <div key={entity.name} className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-2">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <span className="font-extrabold text-slate-900 text-xs">{entity.name}</span>
                      <span className="font-mono text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded">
                        PK: {entity.pk}
                      </span>
                    </div>
                    <p className="text-[10px] font-mono text-purple-700 bg-purple-50 p-1.5 rounded">
                      FK: {entity.fk}
                    </p>
                    <p className="text-[10px] text-slate-500 font-semibold">{entity.rel}</p>
                    <div className="pt-2 border-t border-slate-100 flex flex-wrap gap-1">
                      {entity.cols.map(c => (
                        <span key={c} className="text-[9px] font-mono bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Database Schema Tables */}
          {activeTab === 'schema' && (
            <div className="space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900">Relational Database Tables Definition (3NF)</h3>
              
              <div className="border border-slate-200 rounded-2xl overflow-hidden">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-900 text-white font-bold">
                      <th className="p-3">Table Name</th>
                      <th className="p-3">Primary Key</th>
                      <th className="p-3">Foreign Keys</th>
                      <th className="p-3">Description & Relationships</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 bg-white">
                    <tr>
                      <td className="p-3 font-mono font-bold text-rose-600">Users</td>
                      <td className="p-3 font-mono">id (UUID)</td>
                      <td className="p-3 font-mono text-slate-400">None</td>
                      <td className="p-3">Central auth user model storing credentials, role, and wallet balance.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-rose-600">Restaurant</td>
                      <td className="p-3 font-mono">id (UUID)</td>
                      <td className="p-3 font-mono">owner_id (Users)</td>
                      <td className="p-3">Outlet profiles, operating hours, delivery fees, rating, and address.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-rose-600">FoodItem</td>
                      <td className="p-3 font-mono">id (UUID)</td>
                      <td className="p-3 font-mono">restaurant_id, category_id</td>
                      <td className="p-3">Individual menu dishes with veg/non-veg badge, price, and prep time.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-rose-600">Order</td>
                      <td className="p-3 font-mono">id (UUID)</td>
                      <td className="p-3 font-mono">user_id, restaurant_id, address_id</td>
                      <td className="p-3">Customer order transaction header with live status stepper.</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-mono font-bold text-rose-600">Payment</td>
                      <td className="p-3 font-mono">id (UUID)</td>
                      <td className="p-3 font-mono">order_id, user_id</td>
                      <td className="p-3">Gateway transaction record storing status, gateway type, and transaction ID.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Architecture Tab */}
          {activeTab === 'architecture' && (
            <div className="space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900">Django MVT Architecture & Directory Layout</h3>
              
              <div className="p-4 rounded-2xl bg-slate-900 text-slate-200 font-mono text-[11px] leading-relaxed">
                <pre>{`crave_craft/
│── manage.py
│── requirements.txt
│── README.md
│── crave_craft/           # Core settings, urls.py, wsgi.py
│── accounts/              # Authentication, CustomerProfile, User models
│── restaurants/           # Restaurant partner listings & timings
│── menu/                  # Food Categories, Dishes, Customizations
│── cart/                  # Session & DB Cart management
│── orders/                # Order placement, checkout, live tracking
│── payments/              # Razorpay, Stripe, Paypal, Wallet logic
│── dashboard/             # Customer & Admin analytical control panel
│── static/                # Compiled CSS, JS, Images
└── templates/             # Jinja2 / Django HTML templates`}</pre>
              </div>
            </div>
          )}

          {/* API Docs Tab */}
          {activeTab === 'api' && (
            <div className="space-y-3">
              <h3 className="font-extrabold text-sm text-slate-900">REST API Endpoints</h3>
              <div className="space-y-2">
                {[
                  { method: 'GET', path: '/api/restaurants', desc: 'List & filter restaurants by category, veg status, rating' },
                  { method: 'GET', path: '/api/restaurants/:id', desc: 'Fetch detailed outlet profile and full food menu' },
                  { method: 'POST', path: '/api/coupons/validate', desc: 'Validate promo code and calculate discount amount' },
                  { method: 'POST', path: '/api/orders', desc: 'Place new food order with payment gateway authorization' },
                  { method: 'GET', path: '/api/analytics', desc: 'Admin analytics report for revenue, sales charts, and top dishes' },
                ].map(ep => (
                  <div key={ep.path} className="p-3 rounded-xl border border-slate-200 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className={`px-2 py-0.5 rounded font-mono font-bold text-[10px] ${
                        ep.method === 'GET' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {ep.method}
                      </span>
                      <span className="font-mono font-bold text-slate-900">{ep.path}</span>
                    </div>
                    <span className="text-slate-500 text-[11px]">{ep.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Security Tab */}
          {activeTab === 'security' && (
            <div className="space-y-4">
              <h3 className="font-extrabold text-sm text-slate-900">Security & Best Practices Implemented</h3>
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="p-3.5 rounded-2xl border border-slate-200 bg-emerald-50/50">
                  <h4 className="font-extrabold text-emerald-950">CSRF & XSS Protection</h4>
                  <p className="text-slate-600 mt-0.5">All forms pass anti-CSRF token verification and input sanitization.</p>
                </div>
                <div className="p-3.5 rounded-2xl border border-slate-200 bg-purple-50/50">
                  <h4 className="font-extrabold text-purple-950">Password Hashing</h4>
                  <p className="text-slate-600 mt-0.5">Passwords hashed using PBKDF2 / SHA256 algorithm before storage.</p>
                </div>
                <div className="p-3.5 rounded-2xl border border-slate-200 bg-blue-50/50">
                  <h4 className="font-extrabold text-blue-950">Role-Based Access Control (RBAC)</h4>
                  <p className="text-slate-600 mt-0.5">Strict authorization middleware separating Customer, Owner, and Super Admin permissions.</p>
                </div>
                <div className="p-3.5 rounded-2xl border border-slate-200 bg-amber-50/50">
                  <h4 className="font-extrabold text-amber-950">Secure Session Cookies</h4>
                  <p className="text-slate-600 mt-0.5">HttpOnly, SameSite=Strict cookies preventing session hijacking.</p>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};

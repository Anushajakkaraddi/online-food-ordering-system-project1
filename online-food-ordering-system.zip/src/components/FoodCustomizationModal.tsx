import React, { useState } from 'react';
import { X, Check, Plus, Minus, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CartItemOption } from '../types';

export const FoodCustomizationModal: React.FC = () => {
  const { selectedFoodItem, setSelectedFoodItem, addToCart } = useApp();

  if (!selectedFoodItem) return null;

  const [quantity, setQuantity] = useState(1);
  const [selectedOptions, setSelectedOptions] = useState<CartItemOption[]>(() => {
    // Select default required options
    const defaults: CartItemOption[] = [];
    selectedFoodItem.customizationGroups?.forEach(group => {
      if (group.required && group.options.length > 0) {
        const opt = group.options[0];
        defaults.push({
          groupId: group.id,
          groupTitle: group.title,
          optionId: opt.id,
          optionName: opt.name,
          price: opt.price,
        });
      }
    });
    return defaults;
  });
  const [instructions, setInstructions] = useState('');

  const basePrice = selectedFoodItem.discountPrice || selectedFoodItem.price;
  const optionsPrice = selectedOptions.reduce((acc, opt) => acc + opt.price, 0);
  const unitTotal = basePrice + optionsPrice;
  const grandTotal = unitTotal * quantity;

  const handleToggleOption = (groupId: string, groupTitle: string, optionId: string, optionName: string, price: number, isRequired: boolean) => {
    setSelectedOptions(prev => {
      if (isRequired) {
        // Replace existing option for required group
        const filtered = prev.filter(opt => opt.groupId !== groupId);
        return [...filtered, { groupId, groupTitle, optionId, optionName, price }];
      } else {
        // Toggle for optional group
        const exists = prev.some(opt => opt.optionId === optionId);
        if (exists) {
          return prev.filter(opt => opt.optionId !== optionId);
        } else {
          return [...prev, { groupId, groupTitle, optionId, optionName, price }];
        }
      }
    });
  };

  const handleAddToCart = () => {
    addToCart(selectedFoodItem, quantity, selectedOptions, instructions);
    setSelectedFoodItem(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white rounded-3xl max-w-lg w-full max-h-[90vh] flex flex-col overflow-hidden shadow-2xl border border-slate-100">
        
        {/* Header */}
        <div className="relative h-44 overflow-hidden bg-slate-100">
          <img
            src={selectedFoodItem.image}
            alt={selectedFoodItem.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

          <button
            onClick={() => setSelectedFoodItem(null)}
            className="absolute top-3 right-3 p-2 rounded-full bg-black/50 text-white hover:bg-black/70 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-3 left-4 right-4 text-white">
            <h3 className="font-extrabold text-lg leading-tight">{selectedFoodItem.name}</h3>
            <p className="text-xs text-slate-300 line-clamp-1 mt-0.5">{selectedFoodItem.description}</p>
          </div>
        </div>

        {/* Options Content */}
        <div className="p-5 overflow-y-auto flex-1 space-y-6">
          
          {selectedFoodItem.customizationGroups?.map(group => (
            <div key={group.id} className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
                <span className="font-extrabold text-slate-900 text-sm">{group.title}</span>
                <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                  group.required ? 'bg-amber-100 text-amber-900' : 'bg-slate-100 text-slate-600'
                }`}>
                  {group.required ? 'Required' : 'Optional'}
                </span>
              </div>

              <div className="space-y-2">
                {group.options.map(opt => {
                  const isSelected = selectedOptions.some(o => o.optionId === opt.id);

                  return (
                    <div
                      key={opt.id}
                      onClick={() => handleToggleOption(group.id, group.title, opt.id, opt.name, opt.price, group.required)}
                      className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
                        isSelected 
                          ? 'bg-rose-50/60 border-rose-500 text-rose-950' 
                          : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                          isSelected ? 'bg-rose-600 border-rose-600 text-white' : 'border-slate-300'
                        }`}>
                          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>
                        <span className="font-semibold text-xs">{opt.name}</span>
                      </div>

                      <span className="font-bold text-xs">
                        {opt.price > 0 ? `+$${opt.price.toFixed(2)}` : 'Free'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Special Instructions Input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Chef Instructions / Cooking Request
            </label>
            <input
              type="text"
              placeholder="e.g. Less spicy, extra sauce on side..."
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
            />
          </div>

        </div>

        {/* Footer Bar */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-4">
          
          {/* Quantity Selector */}
          <div className="flex items-center gap-3 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-xs">
            <button
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="p-1 hover:bg-slate-100 rounded-md text-slate-600 transition-colors cursor-pointer"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="font-black text-sm text-slate-900 w-4 text-center">{quantity}</span>
            <button
              onClick={() => setQuantity(quantity + 1)}
              className="p-1 hover:bg-slate-100 rounded-md text-slate-600 transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Add Button */}
          <button
            onClick={handleAddToCart}
            className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-700 hover:to-rose-600 text-white font-extrabold text-xs shadow-md flex items-center justify-between transition-all cursor-pointer"
          >
            <span>Add Item</span>
            <span>${grandTotal.toFixed(2)}</span>
          </button>

        </div>

      </div>
    </div>
  );
};

import React from 'react';
import { Star, Plus, Minus, Flame, Heart, Sparkles, Clock } from 'lucide-react';
import { FoodItem } from '../types';
import { useApp } from '../context/AppContext';

interface FoodCardProps {
  foodItem: FoodItem;
}

export const FoodCard: React.FC<FoodCardProps> = ({ foodItem }) => {
  const { 
    cartItems, addToCart, updateCartQuantity, 
    wishlist, toggleWishlist, setSelectedFoodItem 
  } = useApp();

  const isFav = wishlist.includes(foodItem.id);

  // Find if item is in cart
  const cartItem = cartItems.find(item => item.foodItem.id === foodItem.id);
  const cartQty = cartItem ? cartItem.quantity : 0;

  const handleAddClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (foodItem.customizationGroups && foodItem.customizationGroups.length > 0) {
      setSelectedFoodItem(foodItem);
    } else {
      addToCart(foodItem, 1);
    }
  };

  return (
    <div className="group bg-white rounded-2xl border border-slate-200/80 p-3.5 sm:p-4 hover:border-orange-300 hover:shadow-md transition-all duration-300 flex flex-col justify-between relative">
      
      {/* Top Details & Image */}
      <div className="flex gap-3.5">
        
        {/* Left Info Column */}
        <div className="flex-1 min-w-0">
          
          {/* Veg / Non-Veg Badge & Badges */}
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            
            {/* Veg Symbol */}
            <div className={`w-4 h-4 border-2 flex items-center justify-center p-0.5 rounded-xs ${
              foodItem.type === 'veg' ? 'border-emerald-600' : 'border-rose-600'
            }`}>
              <div className={`w-2 h-2 rounded-full ${
                foodItem.type === 'veg' ? 'bg-emerald-600' : 'bg-rose-600'
              }`} />
            </div>

            {foodItem.isBestseller && (
              <span className="bg-orange-50 text-orange-900 border border-orange-200 font-extrabold text-[9px] uppercase px-1.5 py-0.5 rounded-md flex items-center gap-0.5">
                <Sparkles className="w-2.5 h-2.5 text-orange-600" /> Bestseller
              </span>
            )}

            {foodItem.calories && (
              <span className="text-[10px] text-slate-400 font-medium">
                {foodItem.calories} kcal
              </span>
            )}
          </div>

          {/* Dish Name */}
          <h4 className="font-extrabold text-slate-900 text-sm sm:text-base leading-snug group-hover:text-orange-600 transition-colors line-clamp-1">
            {foodItem.name}
          </h4>

          {/* Pricing */}
          <div className="flex items-baseline gap-2 mt-1">
            <span className="font-black text-slate-900 text-sm sm:text-base">
              ${(foodItem.discountPrice || foodItem.price).toFixed(2)}
            </span>
            {foodItem.discountPrice && (
              <span className="text-xs text-slate-400 line-through font-medium">
                ${foodItem.price.toFixed(2)}
              </span>
            )}
          </div>

          {/* Rating & Prep Time */}
          <div className="flex items-center gap-2 mt-2 text-xs">
            <div className="flex items-center gap-1 font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded-md text-[11px]">
              <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
              <span>{foodItem.rating}</span>
              <span className="text-slate-400 font-normal">({foodItem.ratingCount})</span>
            </div>

            <div className="flex items-center gap-1 text-[11px] text-slate-500 font-medium">
              <Clock className="w-3 h-3 text-slate-400" />
              <span>{foodItem.prepTimeMinutes} mins</span>
            </div>
          </div>

          {/* Description */}
          <p className="text-slate-500 text-xs mt-2 line-clamp-2 leading-relaxed">
            {foodItem.description}
          </p>

        </div>

        {/* Right Dish Image & Add Control */}
        <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-2xl overflow-hidden bg-slate-100 shrink-0">
          <img
            src={foodItem.image}
            alt={foodItem.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />

          {/* Wishlist Heart */}
          <button
            onClick={() => toggleWishlist(foodItem.id)}
            className="absolute top-1.5 right-1.5 p-1.5 rounded-full bg-white/80 hover:bg-white text-slate-700 shadow-xs transition-colors cursor-pointer"
          >
            <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-orange-500 text-orange-500' : 'text-slate-600'}`} />
          </button>

          {/* Add to Cart Overlay Button */}
          <div className="absolute bottom-1.5 left-1.5 right-1.5">
            {cartQty > 0 && !cartItem?.selectedOptions?.length ? (
              <div className="flex items-center justify-between bg-orange-500 text-white rounded-xl py-1 px-2 font-bold text-xs shadow-sm">
                <button
                  onClick={() => updateCartQuantity(cartItem!.id, -1)}
                  className="p-1 hover:bg-orange-600 rounded-md transition-colors cursor-pointer"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="font-extrabold">{cartQty}</span>
                <button
                  onClick={() => updateCartQuantity(cartItem!.id, 1)}
                  className="p-1 hover:bg-orange-600 rounded-md transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={handleAddClick}
                className="w-full py-1.5 px-3 rounded-xl bg-white/95 hover:bg-white text-orange-600 font-extrabold text-xs shadow-sm border border-orange-200 uppercase tracking-wide hover:scale-102 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-1"
              >
                <span>ADD</span>
                <Plus className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

        </div>

      </div>

      {foodItem.customizationGroups && foodItem.customizationGroups.length > 0 && (
        <div className="mt-2 text-[10px] text-center text-slate-400 font-medium tracking-tight">
          Customizable options available
        </div>
      )}

    </div>
  );
};

import React from 'react';
import { UtensilsCrossed, Heart, ShieldCheck, FileText, Phone, Mail, MapPin } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Footer: React.FC = () => {
  const { setCurrentView, setIsDocumentationModalOpen } = useApp();

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800/80 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-12 border-b border-slate-800/80">
          
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-orange-500 flex items-center justify-center text-white shadow-xs">
                <UtensilsCrossed className="w-5 h-5" />
              </div>
              <span className="text-2xl font-black text-white tracking-tight">CraveCraft</span>
            </div>

            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              CraveCraft is a final year BCA project demonstrating a full-stack online food ordering system with real-time order tracking, multi-gateway checkout, and admin analytics.
            </p>

            <div className="flex items-center gap-2 text-xs text-orange-400 font-bold bg-orange-500/10 px-3 py-1.5 rounded-xl border border-orange-500/20 w-fit">
              <ShieldCheck className="w-4 h-4" />
              <span>Production-Ready BCA Project</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-extrabold text-white text-xs uppercase tracking-wider mb-3">Quick Navigation</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setCurrentView('home')} className="hover:text-white transition-colors cursor-pointer">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('restaurants')} className="hover:text-white transition-colors cursor-pointer">
                  Explore Restaurants
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('customer_dashboard')} className="hover:text-white transition-colors cursor-pointer">
                  Customer Dashboard
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('admin_dashboard')} className="hover:text-white transition-colors cursor-pointer">
                  Admin Console
                </button>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-extrabold text-white text-xs uppercase tracking-wider mb-3">Popular Cuisines</h4>
            <ul className="space-y-2 text-xs">
              <li>Biryani & Mughlai</li>
              <li>Wood-fired Pizza</li>
              <li>Craft Burgers</li>
              <li>Chinese & Asian Wok</li>
              <li>South & North Indian</li>
            </ul>
          </div>

          {/* Project Specs */}
          <div>
            <h4 className="font-extrabold text-white text-xs uppercase tracking-wider mb-3">Project Specs</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button 
                  onClick={() => setIsDocumentationModalOpen(true)}
                  className="text-orange-400 hover:underline font-bold flex items-center gap-1 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>ER Diagram & Schema</span>
                </button>
              </li>
              <li>Django MVT Architecture</li>
              <li>3NF Database Model</li>
              <li>Multi-Gateway Checkout</li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© 2026 CraveCraft Inc. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Engineered with <Heart className="w-3.5 h-3.5 text-orange-500 fill-orange-500" /> for BCA Final Year Project
          </p>
        </div>

      </div>
    </footer>
  );
};

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { FOOD_CATEGORIES, RESTAURANTS, FOOD_ITEMS, AVAILABLE_COUPONS, MOCK_ORDERS, MOCK_REVIEWS, INITIAL_USER } from './src/data/mockData.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Memory database stores for server endpoints
  const restaurants = [...RESTAURANTS];
  const foodItems = [...FOOD_ITEMS];
  const coupons = [...AVAILABLE_COUPONS];
  const orders = [...MOCK_ORDERS];
  const reviews = [...MOCK_REVIEWS];

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // Get Restaurants
  app.get('/api/restaurants', (req, res) => {
    const { category, search, veg, sort } = req.query;
    let list = [...restaurants];

    if (search && typeof search === 'string') {
      const q = search.toLowerCase();
      list = list.filter(r => 
        r.name.toLowerCase().includes(q) || 
        r.cuisines.some(c => c.toLowerCase().includes(q))
      );
    }

    if (veg === 'true') {
      list = list.filter(r => r.isPureVeg);
    }

    if (category && typeof category === 'string') {
      list = list.filter(r => r.cuisines.some(c => c.toLowerCase() === category.toLowerCase()));
    }

    if (sort === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    } else if (sort === 'delivery_time') {
      list.sort((a, b) => a.deliveryTimeMinutes - b.deliveryTimeMinutes);
    } else if (sort === 'cost_low') {
      list.sort((a, b) => a.avgCostForTwo - b.avgCostForTwo);
    }

    res.json(list);
  });

  // Get Restaurant by ID or Slug
  app.get('/api/restaurants/:id', (req, res) => {
    const { id } = req.params;
    const rest = restaurants.find(r => r.id === id || r.slug === id);
    if (!rest) {
      return res.status(404).json({ error: 'Restaurant not found' });
    }
    const items = foodItems.filter(f => f.restaurantId === rest.id);
    res.json({ ...rest, menuItems: items });
  });

  // Get Food Categories
  app.get('/api/categories', (req, res) => {
    res.json(FOOD_CATEGORIES);
  });

  // Get Food Items
  app.get('/api/food-items', (req, res) => {
    const { category, search, type } = req.query;
    let items = [...foodItems];

    if (search && typeof search === 'string') {
      const q = search.toLowerCase();
      items = items.filter(f => f.name.toLowerCase().includes(q) || f.description.toLowerCase().includes(q));
    }

    if (category && typeof category === 'string') {
      items = items.filter(f => f.category.toLowerCase() === category.toLowerCase());
    }

    if (type && typeof type === 'string') {
      items = items.filter(f => f.type === type);
    }

    res.json(items);
  });

  // Coupons
  app.get('/api/coupons', (req, res) => {
    res.json(coupons);
  });

  // Validate coupon
  app.post('/api/coupons/validate', (req, res) => {
    const { code, orderAmount } = req.body;
    const coupon = coupons.find(c => c.code.toUpperCase() === (code || '').toUpperCase() && c.isActive);
    if (!coupon) {
      return res.status(400).json({ error: 'Invalid or expired coupon code' });
    }
    if (orderAmount < coupon.minOrderValue) {
      return res.status(400).json({ error: `Minimum order amount of $${coupon.minOrderValue} required for this coupon.` });
    }

    let discount = 0;
    if (coupon.discountType === 'percentage') {
      discount = (orderAmount * coupon.discountValue) / 100;
      if (coupon.maxDiscount && discount > coupon.maxDiscount) {
        discount = coupon.maxDiscount;
      }
    } else {
      discount = coupon.discountValue;
    }

    res.json({ coupon, discountAmount: Number(discount.toFixed(2)) });
  });

  // Get Orders
  app.get('/api/orders', (req, res) => {
    res.json(orders);
  });

  // Create Order
  app.post('/api/orders', (req, res) => {
    const newOrder = req.body;
    newOrder.id = `ord_${Date.now()}`;
    newOrder.orderNumber = `CRV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    newOrder.placedAt = new Date().toISOString();
    orders.unshift(newOrder);
    res.status(201).json(newOrder);
  });

  // Update Order Status
  app.patch('/api/orders/:id/status', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const order = orders.find(o => o.id === id);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    order.status = status;
    res.json(order);
  });

  // Analytics endpoint for Admin
  app.get('/api/analytics', (req, res) => {
    const totalRevenue = orders.reduce((acc, o) => acc + (o.paymentStatus === 'completed' ? o.grandTotal : 0), 0);
    const totalOrders = orders.length;

    const analytics = {
      dailySales: [
        { date: 'Mon', amount: 420, orders: 18 },
        { date: 'Tue', amount: 580, orders: 24 },
        { date: 'Wed', amount: 640, orders: 29 },
        { date: 'Thu', amount: 890, orders: 36 },
        { date: 'Fri', amount: 1250, orders: 54 },
        { date: 'Sat', amount: 1680, orders: 72 },
        { date: 'Sun', amount: 1420, orders: 61 },
      ],
      monthlySales: [
        { month: 'Jan', amount: 12400, orders: 510 },
        { month: 'Feb', amount: 14200, orders: 590 },
        { month: 'Mar', amount: 16800, orders: 680 },
        { month: 'Apr', amount: 18900, orders: 740 },
        { month: 'May', amount: 22100, orders: 890 },
        { month: 'Jun', amount: 25400, orders: 1020 },
      ],
      topCategories: FOOD_CATEGORIES.slice(0, 5).map(c => ({ name: c.name, sales: Math.floor(Math.random() * 500) + 200 })),
      topDishes: foodItems.slice(0, 5).map(f => ({ name: f.name, quantity: Math.floor(Math.random() * 150) + 50, revenue: Math.floor(Math.random() * 2000) + 500 })),
      topRestaurants: restaurants.slice(0, 4).map(r => ({ name: r.name, orders: Math.floor(Math.random() * 300) + 100, revenue: Math.floor(Math.random() * 5000) + 1500 })),
      overallStats: {
        totalRevenue: Number((totalRevenue + 45890).toFixed(2)),
        totalOrders: totalOrders + 1840,
        activeCustomers: 1240,
        activeRestaurants: restaurants.length,
        avgOrderValue: 24.50,
      }
    };
    res.json(analytics);
  });

  // Vite middleware in dev mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
